import { describe, it, expect } from 'vitest'
import { readFileSync, readdirSync } from 'node:fs'
import path from 'node:path'

const migrationsDir = path.join(__dirname, '..', 'supabase', 'migrations')
const migrations = readdirSync(migrationsDir)
  .filter((f) => f.endsWith('.sql'))
  .map((f) => readFileSync(path.join(migrationsDir, f), 'utf8'))
  .join('\n')

describe('database security (migrations)', () => {
  it('enables RLS on every application table', () => {
    for (const table of ['profiles', 'user_roles', 'categories', 'menu_items', 'restaurant_settings', 'opening_hours']) {
      expect(migrations).toContain(`alter table public.${table} enable row level security`)
    }
  })

  it('provides a security definer is_owner() check', () => {
    expect(migrations).toContain('security definer')
    expect(migrations).toContain('public.is_owner()')
  })

  it('restricts public menu reads to published rows only', () => {
    expect(migrations).toContain('menu_items_public_read')
    expect(migrations).toContain('is_published = true')
  })

  it('scopes storage writes to the verified owner', () => {
    expect(migrations).toContain("bucket_id = 'menu-images'")
    expect(migrations).toContain('menu_images_owner_insert')
  })

  it('contains no sample menu content', () => {
    expect(migrations.toLowerCase()).not.toContain('lorem')
    // only the restaurant name / currency defaults are seeded
    expect(migrations).not.toContain('insert into public.menu_items')
  })
})

describe('client bundle hygiene', () => {
  const walk = (dir: string): string[] =>
    readdirSync(dir, { withFileTypes: true }).flatMap((e) =>
      e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)],
    )

  it('never references service-role keys in source', () => {
    const files = walk(path.join(__dirname, '..', 'src'))
    for (const file of files) {
      const content = readFileSync(file, 'utf8')
      expect(content).not.toContain('service_role')
      expect(content).not.toContain('SERVICE_ROLE')
    }
  })
})
