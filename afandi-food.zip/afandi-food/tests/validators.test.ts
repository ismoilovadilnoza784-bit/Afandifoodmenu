import { describe, it, expect } from 'vitest'
import { menuItemSchema, categorySchema, hoursSchema, settingsSchema } from '@/lib/validators'

describe('menuItemSchema', () => {
  const base = {
    name_uz: 'Palov',
    name_ru: '',
    name_en: '',
    description_uz: '',
    description_ru: '',
    description_en: '',
    price: '',
    currency: 'UZS',
    is_published: 'on',
    is_available: 'on',
    sort_order: '0',
    remove_image: '',
  }

  it('accepts a minimal valid dish', () => {
    const result = menuItemSchema.safeParse(base)
    expect(result.success).toBe(true)
    if (result.success) {
      expect(result.data.price).toBeNull()
      expect(result.data.is_published).toBe(true)
      expect(result.data.category_id).toBeNull()
    }
  })

  it('rejects an empty Uzbek name', () => {
    const result = menuItemSchema.safeParse({ ...base, name_uz: '   ' })
    expect(result.success).toBe(false)
  })

  it('rejects a negative price', () => {
    const result = menuItemSchema.safeParse({ ...base, price: '-10' })
    expect(result.success).toBe(false)
  })

  it('rejects a non-numeric price', () => {
    const result = menuItemSchema.safeParse({ ...base, price: 'abc' })
    expect(result.success).toBe(false)
  })

  it('maps missing checkboxes to false', () => {
    const result = menuItemSchema.safeParse({ ...base, is_published: '', is_available: '' })
    expect(result.success).toBe(true)
    if (result.success) {
      expect(result.data.is_published).toBe(false)
      expect(result.data.is_available).toBe(false)
    }
  })

  it('rejects an invalid category uuid', () => {
    const result = menuItemSchema.safeParse({ ...base, category_id: 'not-a-uuid' })
    expect(result.success).toBe(false)
  })
})

describe('categorySchema', () => {
  it('rejects slugs with uppercase or spaces', () => {
    const result = categorySchema.safeParse({
      name_uz: 'Salads',
      name_ru: '',
      name_en: '',
      slug: 'Not A Slug',
      sort_order: '0',
      is_published: 'on',
    })
    expect(result.success).toBe(false)
  })

  it('accepts an empty slug (auto-generated server-side)', () => {
    const result = categorySchema.safeParse({
      name_uz: 'Salatlar',
      name_ru: '',
      name_en: '',
      slug: '',
      sort_order: '2',
      is_published: 'on',
    })
    expect(result.success).toBe(true)
  })
})

describe('hoursSchema', () => {
  const baseRow = { is_closed: '', open_time: '', close_time: '' }
  const rows = Array.from({ length: 7 }, (_, i) => ({ day_of_week: String(i), ...baseRow }))

  it('requires times on open days', () => {
    const result = hoursSchema.safeParse(rows.map((r, i) => (i === 0 ? { ...r, open_time: '09:00' } : r)))
    expect(result.success).toBe(false)
  })

  it('accepts closed days without times', () => {
    const closed = rows.map((r, i) => (i === 0 ? { ...r, is_closed: 'on' } : r))
    const result = hoursSchema.safeParse(closed)
    expect(result.success).toBe(true)
  })
})

describe('settingsSchema', () => {
  it('requires the restaurant name', () => {
    expect(settingsSchema.safeParse({ name: '' }).success).toBe(false)
  })
})
