import { describe, it, expect } from 'vitest'
import { pickLocalized, isLang, dict } from '@/lib/i18n'

describe('pickLocalized', () => {
  const row = { name_uz: 'Palov', name_ru: 'Плов', name_en: null }

  it('returns the requested language when present', () => {
    expect(pickLocalized(row, 'name', 'ru')).toBe('Плов')
  })

  it('falls back to Uzbek when the requested translation is missing', () => {
    expect(pickLocalized(row, 'name', 'en')).toBe('Palov')
  })

  it('returns an empty string when nothing is supplied — never invents content', () => {
    expect(pickLocalized({}, 'name', 'uz')).toBe('')
  })
})

describe('isLang', () => {
  it('accepts uz, ru, en and rejects others', () => {
    expect(isLang('uz')).toBe(true)
    expect(isLang('ru')).toBe(true)
    expect(isLang('en')).toBe(true)
    expect(isLang('fr')).toBe(false)
    expect(isLang(undefined)).toBe(false)
  })
})

describe('dictionaries', () => {
  it('has identical key sets for all three languages', () => {
    const keys = (o: object) => Object.keys(o).sort().join(',')
    expect(keys(dict('uz'))).toBe(keys(dict('ru')))
    expect(keys(dict('ru'))).toBe(keys(dict('en')))
  })

  it('defaults to Uzbek', () => {
    expect(dict('uz').menuTitle).toBe('Menyu')
  })
})
