import { describe, it, expect } from 'vitest'
import { slugify, formatPrice, storagePublicUrl } from '@/lib/utils'

describe('slugify', () => {
  it('creates URL-safe slugs', () => {
    expect(slugify('Grill Menu')).toBe('grill-menu')
    expect(slugify('  Salatlar & Soups!! ')).toBe('salatlar-soups')
  })

  it('transliterates common Uzbek Cyrillic characters', () => {
    expect(slugify('Плов')).toBe('plov')
  })

  it('handles Uzbek apostrophe letters', () => {
    expect(slugify("Go'sht")).toBe('gosh t'.replace(' ', '')) // oʻ -> o
  })
})

describe('formatPrice', () => {
  it('formats UZS without decimals', () => {
    const formatted = formatPrice(45000, 'UZS', 'uz')
    expect(formatted).toContain('45')
    expect(formatted).not.toContain('.00')
  })

  it('returns null for missing prices', () => {
    expect(formatPrice(null, 'UZS', 'en')).toBeNull()
  })
})

describe('storagePublicUrl', () => {
  it('builds the public storage URL', () => {
    expect(storagePublicUrl('https://x.supabase.co', 'items/a.jpg')).toBe(
      'https://x.supabase.co/storage/v1/object/public/menu-images/items/a.jpg',
    )
  })
})
