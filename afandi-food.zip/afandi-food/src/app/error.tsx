'use client'

export default function Error({
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-charcoal px-6 text-center">
      <h1 className="font-serif text-2xl text-ivory">Something went wrong</h1>
      <p className="mt-2 max-w-md text-muted">
        The menu could not be loaded. Please check your connection and try again.
      </p>
      <button
        onClick={reset}
        className="mt-8 rounded-full border border-gold/50 px-6 py-2 text-sm text-gold transition hover:bg-gold/10"
      >
        Try again
      </button>
    </main>
  )
}
