import { redirect } from 'next/navigation'

// The homepage sends QR-scanners straight to the public menu.
export default function Home() {
  redirect('/menu')
}
