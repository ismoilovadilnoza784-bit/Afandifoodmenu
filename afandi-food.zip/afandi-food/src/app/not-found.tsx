import Link from 'next/link'

export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-charcoal px-6 text-center">
      <p className="font-serif text-6xl text-gold">404</p>
      <h1 className="mt-4 font-serif text-2xl text-ivory">Sahifa topilmadi</h1>
      <p className="mt-2 text-muted">The page you are looking for does not exist.</p>
      <Link
        href="/menu"
        className="mt-8 rounded-full border border-gold/50 px-6 py-2 text-sm text-gold transition hover:bg-gold/10"
      >
        Menyu
      </Link>
    </main>
  )
}
