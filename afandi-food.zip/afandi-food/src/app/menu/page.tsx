import type { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { getLang, dict, pickLocalized, type Lang } from '@/lib/i18n'
import { formatPrice, formatTime, dayName, storagePublicUrl } from '@/lib/utils'
import { MenuClient } from '@/components/menu/MenuClient'
import { EmptyMenu } from '@/components/menu/EmptyMenu'
import { LanguageSwitcher } from '@/components/menu/LanguageSwitcher'
import type { CategoryView, DishView } from '@/components/menu/types'
import type { CategoryRow, MenuItemRow, OpeningHoursRow, SettingRow } from '@/types/database'

export const metadata: Metadata = {
  title: 'Menyu',
  openGraph: { title: 'Afandi Food — Menyu', type: 'website' },
}

export const revalidate = 30

interface SettingsMap {
  name: string
  tagline: string
  address: string
  phone: string
  heroImage: string | null
}

function toSettings(rows: SettingRow[] | null, lang: Lang): SettingsMap {
  const map = new Map((rows ?? []).map((r) => [r.key, r.value]))
  const str = (k: string) => (typeof map.get(k) === 'string' ? (map.get(k) as string) : '')
  const pickTagline = () => {
    const order = [lang, 'uz', 'ru', 'en'] as const
    for (const l of order) {
      const v = map.get(`tagline_${l}`)
      if (typeof v === 'string' && v.trim()) return v
    }
    return ''
  }
  return {
    name: str('name') || 'Afandi Food',
    tagline: pickTagline(),
    address: str('address'),
    phone: str('phone'),
    heroImage: typeof map.get('hero_image') === 'string' ? (map.get('hero_image') as string) : null,
  }
}

export default async function MenuPage() {
  const lang = getLang()
  const t = dict(lang)
  const supabase = createClient()

  let categories: CategoryRow[] = []
  let items: MenuItemRow[] = []
  let settingsRows: SettingRow[] = []
  let hours: OpeningHoursRow[] = []
  let failed = false

  try {
    const [c, i, s, h] = await Promise.all([
      supabase.from('categories').select('*').eq('is_published', true).order('sort_order'),
      supabase.from('menu_items').select('*').eq('is_published', true).order('sort_order'),
      supabase.from('restaurant_settings').select('key, value'),
      supabase.from('opening_hours').select('*').order('day_of_week'),
    ])
    if (c.error || i.error || s.error) failed = true
    categories = c.data ?? []
    items = i.data ?? []
    settingsRows = s.data ?? []
    hours = h.data ?? []
  } catch {
    failed = true
  }

  if (failed) {
    return (
      <main className="flex min-h-screen flex-col items-center justify-center bg-charcoal px-6 text-center">
        <h1 className="font-serif text-2xl text-ivory">Configuration required</h1>
        <p className="mt-2 max-w-md text-sm text-muted">
          The menu cannot reach the database yet. If you are the owner, set
          NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY and apply
          the SQL migrations — see README.md.
        </p>
      </main>
    )
  }

  const settings = toSettings(settingsRows, lang)

  const categoryViews: CategoryView[] = categories.map((c) => ({
    id: c.id,
    slug: c.slug,
    name: pickLocalized(c, 'name', lang),
  }))

  const dishViews: DishView[] = items.map((i) => ({
    id: i.id,
    category_id: i.category_id,
    name: pickLocalized(i, 'name', lang),
    description: pickLocalized(i, 'description', lang),
    price: formatPrice(i.price, i.currency, lang),
    rawPrice: i.price,
    currency: i.currency,
    imageUrl: i.image_path ? storagePublicUrl(process.env.NEXT_PUBLIC_SUPABASE_URL!, i.image_path) : null,
    is_available: i.is_available,
    sort_order: i.sort_order,
  }))

  const isEmpty = categories.length === 0 && items.length === 0

  return (
    <main className="min-h-screen bg-chardeep">
      <header className="border-b border-ivory/8 bg-charcoal">
        <div className="mx-auto flex max-w-shell items-center justify-between gap-4 px-4 py-4">
          <div>
            <p className="font-serif text-2xl tracking-wide text-ivory">
              {settings.name}
              <span className="ml-2 align-middle text-sm tracking-[0.2em] text-gold">SAMARKAND</span>
            </p>
            {settings.tagline && <p className="mt-1 text-sm text-muted">{settings.tagline}</p>}
          </div>
          <LanguageSwitcher lang={lang} />
        </div>
        {settings.heroImage && (
          <div className="relative mx-auto max-w-shell px-4 pb-4">
            <div className="relative aspect-[21/9] overflow-hidden rounded-2xl border border-ivory/10">
              <Image
                src={storagePublicUrl(process.env.NEXT_PUBLIC_SUPABASE_URL!, settings.heroImage)}
                alt={settings.name}
                fill
                priority
                sizes="(max-width: 72rem) 100vw, 72rem"
                className="object-cover"
              />
            </div>
          </div>
        )}
      </header>

      {isEmpty ? (
        <EmptyMenu lang={lang} name={settings.name} />
      ) : (
        <MenuClient categories={categoryViews} items={dishViews} t={t} />
      )}

      <footer className="mt-12 border-t border-ivory/8 bg-charcoal">
        <div className="mx-auto grid max-w-shell gap-8 px-4 py-10 sm:grid-cols-3">
          <div>
            <p className="font-serif text-lg text-gold">{settings.name}</p>
            {settings.tagline && <p className="mt-1 text-sm text-muted">{settings.tagline}</p>}
          </div>
          <div>
            <p className="text-xs uppercase tracking-widest text-muted">{t.footerContact}</p>
            {settings.address && <p className="mt-2 text-sm text-ivory-dim">{settings.address}</p>}
            {settings.phone && (
              <p className="mt-1 text-sm text-ivory-dim">
                <a href={`tel:${settings.phone.replace(/\s/g, '')}`} className="hover:text-gold">
                  {settings.phone}
                </a>
              </p>
            )}
          </div>
          <div>
            <p className="text-xs uppercase tracking-widest text-muted">{t.footerHours}</p>
            {hours.length === 0 ? (
              <p className="mt-2 text-sm text-muted">—</p>
            ) : (
              <ul className="mt-2 space-y-1 text-sm text-ivory-dim">
                {hours.map((h) => (
                  <li key={h.id} className="flex justify-between gap-4">
                    <span className="capitalize">{dayName(h.day_of_week, lang)}</span>
                    <span>
                      {h.is_closed ? t.closedToday : `${formatTime(h.open_time, lang)} – ${formatTime(h.close_time, lang)}`}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
        <div className="border-t border-ivory/8 py-4 text-center text-xs text-muted">
          <Link href="/owner/login" className="hover:text-gold">
            © {new Date().getFullYear()} {settings.name}
          </Link>
        </div>
      </footer>
    </main>
  )
}
