'use server'

import { cookies } from 'next/headers'
import { langSchema } from '@/lib/validators'

// Persisted UI preference only — never used for authorization.
export async function setLanguage(lang: unknown) {
  const parsed = langSchema.safeParse(lang)
  if (!parsed.success) return
  cookies().set('lang', parsed.data, {
    path: '/',
    maxAge: 60 * 60 * 24 * 365,
    sameSite: 'lax',
  })
}
