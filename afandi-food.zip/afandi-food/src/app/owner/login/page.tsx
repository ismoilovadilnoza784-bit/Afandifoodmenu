import type { Metadata } from 'next'
import Link from 'next/link'
import { getLang, dict } from '@/lib/i18n'
import { LoginForm } from '@/components/owner/LoginForm'

export const metadata: Metadata = { title: 'Owner sign in' }

export default function OwnerLoginPage() {
  const t = dict(getLang())
  return (
    <main className="flex min-h-screen items-center justify-center bg-chardeep px-4">
      <div className="w-full max-w-sm">
        <div className="rounded-2xl border border-ivory/10 bg-charcoal p-8 shadow-card">
          <p className="text-center font-serif text-4xl text-gold">A</p>
          <h1 className="mt-3 text-center font-serif text-xl text-ivory">{t.loginTitle}</h1>
          <p className="mt-1 text-center text-xs uppercase tracking-widest text-muted">
            {t.loginSubtitle}
          </p>
          <LoginForm
            labels={{
              email: t.loginEmail,
              password: t.loginPassword,
              submit: t.loginSubmit,
              forgot: t.loginForgot,
              invalid: t.loginError,
              resetSent: t.loginResetSent,
            }}
          />
        </div>
        <p className="mt-4 text-center">
          <Link href="/menu" className="text-xs text-muted transition hover:text-gold">
            {t.backToMenu}
          </Link>
        </p>
      </div>
    </main>
  )
}
