'use client'

import { useRouter } from 'next/navigation'
import { useState, useTransition } from 'react'
import { saveSettings } from '@/app/owner/actions'
import { inputCls, labelCls, Feedback, LocalizedFields } from '@/components/owner/ui'
import type { SettingsInput } from '@/lib/validators'

export function SettingsForm({ initial }: { initial: SettingsInput }) {
  const router = useRouter()
  const [name, setName] = useState(initial.name)
  const [taglines, setTaglines] = useState({
    uz: initial.tagline_uz ?? '', ru: initial.tagline_ru ?? '', en: initial.tagline_en ?? '',
  })
  const [address, setAddress] = useState(initial.address ?? '')
  const [phone, setPhone] = useState(initial.phone ?? '')
  const [state, setState] = useState<{ ok: boolean; error?: string } | null>(null)
  const [pending, startTransition] = useTransition()

  function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setState(null)
    startTransition(async () => {
      const result = await saveSettings({
        name,
        tagline_uz: taglines.uz,
        tagline_ru: taglines.ru,
        tagline_en: taglines.en,
        address,
        phone,
      })
      setState(result)
      if (result.ok) router.refresh()
    })
  }

  return (
    <form onSubmit={onSubmit} className="space-y-5">
      <Feedback state={state} />
      <div>
        <label htmlFor="rest-name" className={labelCls}>Restaurant name *</label>
        <input id="rest-name" type="text" required value={name} onChange={(e) => setName(e.target.value)} className={inputCls} />
      </div>
      <LocalizedFields
        prefix="tagline"
        values={taglines}
        onChange={(lang, value) => setTaglines((prev) => ({ ...prev, [lang]: value }))}
        labels={{ uz: 'Tagline (Uzbek)', ru: 'Tagline (Russian)', en: 'Tagline (English)' }}
      />
      <div>
        <label htmlFor="address" className={labelCls}>Address</label>
        <input id="address" type="text" value={address} onChange={(e) => setAddress(e.target.value)} className={inputCls} />
      </div>
      <div>
        <label htmlFor="phone" className={labelCls}>Phone</label>
        <input id="phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} className={inputCls} />
      </div>
      <button
        type="submit"
        disabled={pending}
        className="rounded-full bg-gold px-6 py-2.5 text-sm font-medium text-charcoal transition hover:bg-gold-bright disabled:opacity-60"
      >
        {pending ? 'Saving…' : 'Save'}
      </button>
    </form>
  )
}
