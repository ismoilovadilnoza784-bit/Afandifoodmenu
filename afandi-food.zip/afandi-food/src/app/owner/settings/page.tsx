import { createClient } from '@/lib/supabase/server'
import { SettingsForm } from './SettingsForm'
import type { SettingRow } from '@/types/database'

export const metadata = { title: 'Restaurant info' }
export const dynamic = 'force-dynamic'

export default async function OwnerSettingsPage() {
  const supabase = createClient()
  const { data } = await supabase.from('restaurant_settings').select('key, value')
  const map = new Map((data ?? []).map((r: SettingRow) => [r.key, r.value]))
  const str = (k: string) => (typeof map.get(k) === 'string' ? (map.get(k) as string) : '')

  return (
    <div>
      <h1 className="font-serif text-2xl text-ivory">Restaurant information</h1>
      <p className="mt-1 text-sm text-muted">
        This information appears in the menu header and footer for every customer.
      </p>
      <div className="mt-6 max-w-xl rounded-2xl border border-ivory/10 bg-charcoal p-5">
        <SettingsForm
          initial={{
            name: str('name') || 'Afandi Food',
            tagline_uz: str('tagline_uz'),
            tagline_ru: str('tagline_ru'),
            tagline_en: str('tagline_en'),
            address: str('address'),
            phone: str('phone'),
          }}
        />
      </div>
    </div>
  )
}
