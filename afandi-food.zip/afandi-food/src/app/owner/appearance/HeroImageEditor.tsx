'use client'

import { useRouter } from 'next/navigation'
import { useState, useTransition } from 'react'
import { saveHeroImage, removeHeroImage } from '@/app/owner/actions'

export function HeroImageEditor({ hasHero }: { hasHero: boolean }) {
  const router = useRouter()
  const [file, setFile] = useState<File | null>(null)
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null)
  const [pending, startTransition] = useTransition()

  function onUpload(e: React.FormEvent) {
    e.preventDefault()
    setMessage(null)
    if (!file) return
    startTransition(async () => {
      const result = await saveHeroImage(file)
      setMessage(result.ok ? { ok: true, text: 'Header photo updated.' } : { ok: false, text: result.error ?? 'Upload failed' })
      if (result.ok) {
        setFile(null)
        router.refresh()
      }
    })
  }

  function onRemove() {
    if (!window.confirm('Remove the header photo?')) return
    setMessage(null)
    startTransition(async () => {
      const result = await removeHeroImage()
      if (result.ok) router.refresh()
      setMessage(result.ok ? { ok: true, text: 'Header photo removed.' } : { ok: false, text: result.error ?? 'Failed' })
    })
  }

  return (
    <div>
      <form onSubmit={onUpload} className="flex flex-wrap items-center gap-3">
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp,image/avif"
          onChange={(e) => setFile(e.target.files?.[0] ?? null)}
          className="text-sm text-muted file:mr-3 file:rounded-full file:border-0 file:bg-gold file:px-4 file:py-1.5 file:text-xs file:text-charcoal"
        />
        <button
          type="submit"
          disabled={pending || !file}
          className="rounded-full bg-gold px-5 py-2 text-sm font-medium text-charcoal transition hover:bg-gold-bright disabled:opacity-50"
        >
          {pending ? 'Uploading…' : hasHero ? 'Replace photo' : 'Upload photo'}
        </button>
        {hasHero && (
          <button
            type="button"
            onClick={onRemove}
            disabled={pending}
            className="rounded-full border border-red-400/50 px-5 py-2 text-xs text-red-300 transition hover:bg-red-500/10 disabled:opacity-50"
          >
            Remove
          </button>
        )}
      </form>
      {message && (
        <p role={message.ok ? 'status' : 'alert'} className={`mt-3 rounded-xl border px-4 py-2 text-sm ${message.ok ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300' : 'border-red-500/40 bg-red-500/10 text-red-300'}`}>
          {message.text}
        </p>
      )}
      <p className="mt-2 text-xs text-muted">JPEG, PNG, WebP or AVIF, max 5 MB. Recommended: wide photo (21:9).</p>
    </div>
  )
}
