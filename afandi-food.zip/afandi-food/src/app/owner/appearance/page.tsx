import Image from 'next/image'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { env } from '@/lib/env'
import { HeroImageEditor } from './HeroImageEditor'

export const metadata = { title: 'Appearance' }
export const dynamic = 'force-dynamic'

export default async function OwnerAppearancePage() {
  const supabase = createClient()
  const { data } = await supabase.from('restaurant_settings').select('key, value').in('key', ['name', 'hero_image'])
  const map = new Map((data ?? []).map((r) => [r.key as string, r.value]))
  const name = typeof map.get('name') === 'string' ? (map.get('name') as string) : 'Afandi Food'
  const hero = typeof map.get('hero_image') === 'string' ? (map.get('hero_image') as string) : null
  const heroUrl = hero ? `${env.supabaseUrl}/storage/v1/object/public/menu-images/${hero}` : null

  return (
    <div>
      <h1 className="font-serif text-2xl text-ivory">Site appearance</h1>
      <p className="mt-1 text-sm text-muted">
        The menu uses an elegant text wordmark by default. Upload a header photo to complete the
        look — the official logo can be added here later as an image.
      </p>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <section className="rounded-2xl border border-ivory/10 bg-charcoal p-5">
          <h2 className="font-serif text-lg text-ivory">Wordmark</h2>
          <p className="mt-1 text-sm text-muted">
            Currently displayed to customers:
          </p>
          <div className="mt-4 rounded-xl border border-ivory/10 bg-charcoal-deep px-6 py-8 text-center">
            <p className="font-serif text-3xl tracking-wide text-ivory">
              {name}
              <span className="ml-2 align-middle text-sm tracking-[0.25em] text-gold">SAMARKAND</span>
            </p>
          </div>
          <p className="mt-3 text-xs text-muted">
            The name is edited under{' '}
            <Link href="/owner/settings" className="text-gold hover:underline">Restaurant info</Link>.
            Uploading a logo-quality image as the header photo below will visually replace the
            text-only header on the menu.
          </p>
        </section>

        <section className="rounded-2xl border border-ivory/10 bg-charcoal p-5">
          <h2 className="font-serif text-lg text-ivory">Header photo / logo image</h2>
          {heroUrl ? (
            <div className="relative mt-4 aspect-[21/9] overflow-hidden rounded-xl border border-ivory/10">
              <Image src={heroUrl} alt="Current header" fill sizes="(max-width: 40rem) 100vw, 40rem" className="object-cover" />
            </div>
          ) : (
            <div className="mt-4 flex aspect-[21/9] items-center justify-center rounded-xl border border-dashed border-ivory/20 text-sm text-muted">
              No header photo yet
            </div>
          )}
          <div className="mt-4">
            <HeroImageEditor hasHero={Boolean(hero)} />
          </div>
        </section>
      </div>
    </div>
  )
}
