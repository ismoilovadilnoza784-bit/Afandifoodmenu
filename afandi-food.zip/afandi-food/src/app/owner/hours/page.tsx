import { createClient } from '@/lib/supabase/server'
import { HoursForm, type HourRowView } from './HoursForm'

export const metadata = { title: 'Opening hours' }
export const dynamic = 'force-dynamic'

export default async function OwnerHoursPage() {
  const supabase = createClient()
  const { data } = await supabase.from('opening_hours').select('day_of_week, is_closed, open_time, close_time').order('day_of_week')

  const existing = new Map((data ?? []).map((r) => [r.day_of_week as number, r]))
  const rows: HourRowView[] = Array.from({ length: 7 }, (_, day) => {
    const row = existing.get(day)
    return {
      day_of_week: day,
      is_closed: (row?.is_closed as boolean | undefined) ?? true,
      open_time: (row?.open_time as string | undefined)?.slice(0, 5) ?? null,
      close_time: (row?.close_time as string | undefined)?.slice(0, 5) ?? null,
    }
  })

  return (
    <div>
      <h1 className="font-serif text-2xl text-ivory">Opening hours</h1>
      <p className="mt-1 text-sm text-muted">Shown in the footer of the public menu.</p>
      <div className="mt-6">
        <HoursForm initial={rows} />
      </div>
    </div>
  )
}
