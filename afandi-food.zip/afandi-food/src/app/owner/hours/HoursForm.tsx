'use client'

import { useRouter } from 'next/navigation'
import { useState, useTransition } from 'react'
import { saveHours } from '@/app/owner/actions'
import { Feedback } from '@/components/owner/ui'

export interface HourRowView {
  day_of_week: number
  is_closed: boolean
  open_time: string | null
  close_time: string | null
}

export function HoursForm({ initial }: { initial: HourRowView[] }) {
  const router = useRouter()
  const [rows, setRows] = useState(initial)
  const [state, setState] = useState<{ ok: boolean; error?: string } | null>(null)
  const [pending, startTransition] = useTransition()

  function update(day: number, patch: Partial<HourRowView>) {
    setRows((prev) => prev.map((r) => (r.day_of_week === day ? { ...r, ...patch } : r)))
  }

  function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setState(null)
    startTransition(async () => {
      const result = await saveHours(
        rows.map((r) => ({
          day_of_week: r.day_of_week,
          is_closed: r.is_closed ? 'on' : '',
          open_time: r.is_closed ? '' : (r.open_time ?? ''),
          close_time: r.is_closed ? '' : (r.close_time ?? ''),
        })),
      )
      setState(result)
      if (result.ok) router.refresh()
    })
  }

  const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']

  return (
    <form onSubmit={onSubmit} className="space-y-3">
      <Feedback state={state} />
      {rows.map((row) => (
        <div
          key={row.day_of_week}
          className="flex flex-wrap items-center gap-3 rounded-xl border border-ivory/10 bg-charcoal px-4 py-3"
        >
          <span className="w-28 font-serif text-ivory">{dayNames[row.day_of_week]}</span>
          <label className="flex items-center gap-2 text-sm text-ivory/85">
            <input
              type="checkbox"
              checked={row.is_closed}
              onChange={(e) => update(row.day_of_week, { is_closed: e.target.checked })}
              className="accent-gold"
            />
            Closed
          </label>
          {!row.is_closed && (
            <>
              <input
                type="time"
                required
                aria-label={`${dayNames[row.day_of_week]} opening time`}
                value={row.open_time ?? ''}
                onChange={(e) => update(row.day_of_week, { open_time: e.target.value })}
                className="rounded-xl border border-ivory/15 bg-charcoal-soft px-3 py-1.5 text-sm text-ivory focus:border-gold/60 focus:outline-none"
              />
              <span className="text-muted">–</span>
              <input
                type="time"
                required
                aria-label={`${dayNames[row.day_of_week]} closing time`}
                value={row.close_time ?? ''}
                onChange={(e) => update(row.day_of_week, { close_time: e.target.value })}
                className="rounded-xl border border-ivory/15 bg-charcoal-soft px-3 py-1.5 text-sm text-ivory focus:border-gold/60 focus:outline-none"
              />
            </>
          )}
        </div>
      ))}
      <button
        type="submit"
        disabled={pending}
        className="rounded-full bg-gold px-6 py-2.5 text-sm font-medium text-charcoal transition hover:bg-gold-bright disabled:opacity-60"
      >
        {pending ? 'Saving…' : 'Save hours'}
      </button>
    </form>
  )
}
