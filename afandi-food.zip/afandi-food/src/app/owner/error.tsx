'use client'

export default function OwnerError({ reset }: { error: Error; reset: () => void }) {
  return (
    <div className="rounded-2xl border border-red-500/40 bg-red-500/10 p-8 text-center">
      <h1 className="font-serif text-xl text-ivory">Dashboard error</h1>
      <p className="mt-2 text-sm text-muted">The operation failed. Your session may have expired — sign in again.</p>
      <button
        onClick={reset}
        className="mt-6 rounded-full border border-gold/50 px-6 py-2 text-sm text-gold transition hover:bg-gold/10"
      >
        Try again
      </button>
    </div>
  )
}
