'use client'

import { useState, useTransition } from 'react'
import { changePassword } from '@/app/owner/actions'
import { inputCls, labelCls, Feedback } from '@/components/owner/ui'

export function PasswordForm() {
  const [password, setPassword] = useState('')
  const [state, setState] = useState<{ ok: boolean; error?: string } | null>(null)
  const [pending, startTransition] = useTransition()

  function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setState(null)
    startTransition(async () => {
      const form = new FormData()
      form.set('password', password)
      const result = await changePassword(form)
      setState(result)
      if (result.ok) setPassword('')
    })
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <Feedback state={state} />
      <div>
        <label htmlFor="new-password" className={labelCls}>New password</label>
        <input
          id="new-password"
          type="password"
          required
          minLength={8}
          autoComplete="new-password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className={inputCls}
        />
      </div>
      <button
        type="submit"
        disabled={pending}
        className="rounded-full bg-gold px-6 py-2.5 text-sm font-medium text-charcoal transition hover:bg-gold-bright disabled:opacity-60"
      >
        {pending ? 'Updating…' : 'Update password'}
      </button>
    </form>
  )
}
