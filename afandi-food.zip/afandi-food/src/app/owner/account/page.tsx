import { createClient } from '@/lib/supabase/server'
import { PasswordForm } from './PasswordForm'

export const metadata = { title: 'Account & security' }
export const dynamic = 'force-dynamic'

export default async function OwnerAccountPage() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  return (
    <div>
      <h1 className="font-serif text-2xl text-ivory">Account & security</h1>
      <div className="mt-6 max-w-xl space-y-6">
        <section className="rounded-2xl border border-ivory/10 bg-charcoal p-5">
          <h2 className="font-serif text-lg text-ivory">Signed in as</h2>
          <p className="mt-2 text-sm text-ivory-dim">{user?.email}</p>
          <p className="mt-1 text-xs text-muted">
            Owner privileges are verified on the server from the user_roles table on every request.
          </p>
        </section>
        <section className="rounded-2xl border border-ivory/10 bg-charcoal p-5">
          <h2 className="font-serif text-lg text-ivory">Change password</h2>
          <p className="mt-1 text-sm text-muted">Use at least 8 characters.</p>
          <div className="mt-4">
            <PasswordForm />
          </div>
        </section>
        <section className="rounded-2xl border border-ivory/10 bg-charcoal p-5">
          <h2 className="font-serif text-lg text-ivory">Password recovery</h2>
          <p className="mt-1 text-sm text-muted">
            If you forget your password, use “Reset password” on the sign-in page — a recovery link
            will be sent to your email.
          </p>
        </section>
      </div>
    </div>
  )
}
