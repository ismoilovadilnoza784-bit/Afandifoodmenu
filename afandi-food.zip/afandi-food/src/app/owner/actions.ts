'use server'

import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { requireOwner } from '@/lib/auth'
import { slugify, storagePublicUrl } from '@/lib/utils'
import { env, STORAGE_BUCKET } from '@/lib/env'
import {
  menuItemSchema,
  categorySchema,
  settingsSchema,
  hoursSchema,
  type SettingsInput,
  type HoursInput,
} from '@/lib/validators'
import type { Currency } from '@/types/database'

export type ActionResult = { ok: boolean; error?: string; id?: string }

const UNAUTHORIZED: ActionResult = { ok: false, error: 'unauthorized' }

const ALLOWED_IMAGE_TYPES: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/avif': 'avif',
}
const MAX_IMAGE_BYTES = 5 * 1024 * 1024

async function uploadImage(file: File, folder: string): Promise<{ path?: string; error?: string }> {
  if (file.size > MAX_IMAGE_BYTES) {
    return { error: 'Image must be 5 MB or smaller' }
  }
  const ext = ALLOWED_IMAGE_TYPES[file.type]
  if (!ext) {
    return { error: 'Only JPEG, PNG, WebP or AVIF images are allowed' }
  }
  const supabase = createClient()
  const path = `${folder}/${crypto.randomUUID()}.${ext}`
  const { error } = await supabase.storage
    .from(STORAGE_BUCKET)
    .upload(path, file, { contentType: file.type, upsert: false })
  if (error) return { error: 'Upload failed. Please try again.' }
  return { path }
}

async function removeImage(path: string) {
  const supabase = createClient()
  await supabase.storage.from(STORAGE_BUCKET).remove([path])
}

// ---------- Auth ----------

export async function signIn(formData: FormData): Promise<ActionResult> {
  const email = String(formData.get('email') ?? '').trim()
  const password = String(formData.get('password') ?? '')
  if (!email || !password) return { ok: false, error: 'invalid' }

  const supabase = createClient()
  const { error } = await supabase.auth.signInWithPassword({ email, password })
  if (error) return { ok: false, error: 'invalid' }

  const owner = await requireOwner()
  if (!owner) {
    await supabase.auth.signOut()
    return { ok: false, error: 'forbidden' }
  }
  return { ok: true }
}

export async function signOut() {
  const supabase = createClient()
  await supabase.auth.signOut()
  redirect('/owner/login')
}

export async function sendPasswordReset(email: unknown): Promise<ActionResult> {
  const parsed = String(email ?? '').trim()
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(parsed)) return { ok: false, error: 'invalid' }
  const supabase = createClient()
  const { error } = await supabase.auth.resetPasswordForEmail(parsed, {
    redirectTo: `${process.env.NEXT_PUBLIC_SITE_URL ?? ''}/owner/account`,
  })
  // Generic response either way: do not reveal whether the account exists.
  if (error) return { ok: true }
  return { ok: true }
}

export async function changePassword(formData: FormData): Promise<ActionResult> {
  if (!(await requireOwner())) return UNAUTHORIZED
  const password = String(formData.get('password') ?? '')
  if (password.length < 8) return { ok: false, error: 'At least 8 characters' }
  const supabase = createClient()
  const { error } = await supabase.auth.updateUser({ password })
  return error ? { ok: false, error: 'Could not update password' } : { ok: true }
}

// ---------- Categories ----------

export async function saveCategory(input: unknown): Promise<ActionResult> {
  if (!(await requireOwner())) return UNAUTHORIZED
  const parsed = categorySchema.safeParse(input)
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message ?? 'Invalid input' }
  }
  const data = parsed.data
  const supabase = createClient()
  const payload = {
    name_uz: data.name_uz,
    name_ru: data.name_ru,
    name_en: data.name_en,
    slug: data.slug ?? slugify(data.name_uz) ?? `category-${Date.now()}`,
    sort_order: data.sort_order,
    is_published: data.is_published,
  }
  if (data.id) {
    const { error } = await supabase.from('categories').update(payload).eq('id', data.id)
    return error ? { ok: false, error: error.message } : { ok: true, id: data.id }
  }
  const { data: row, error } = await supabase.from('categories').insert(payload).select('id').single()
  return error ? { ok: false, error: error.message } : { ok: true, id: row.id }
}

export async function deleteCategory(id: unknown): Promise<ActionResult> {
  if (!(await requireOwner())) return UNAUTHORIZED
  if (typeof id !== 'string') return { ok: false, error: 'Invalid id' }
  const supabase = createClient()
  const { error } = await supabase.from('categories').delete().eq('id', id)
  return error ? { ok: false, error: error.message } : { ok: true }
}

// ---------- Menu items ----------

export async function saveItem(
  input: unknown,
  image: File | null,
): Promise<ActionResult> {
  if (!(await requireOwner())) return UNAUTHORIZED
  const parsed = menuItemSchema.safeParse(input)
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message ?? 'Invalid input' }
  }
  const data = parsed.data
  const supabase = createClient()

  let imagePath: string | null | undefined
  if (image && image.size > 0) {
    const up = await uploadImage(image, 'items')
    if (up.error) return { ok: false, error: up.error }
    imagePath = up.path
  } else if (data.remove_image && data.id) {
    const { data: existing } = await supabase
      .from('menu_items')
      .select('image_path')
      .eq('id', data.id)
      .single()
    if (existing?.image_path) await removeImage(existing.image_path)
    imagePath = null
  }

  const payload = {
    category_id: data.category_id,
    name_uz: data.name_uz,
    name_ru: data.name_ru,
    name_en: data.name_en,
    description_uz: data.description_uz,
    description_ru: data.description_ru,
    description_en: data.description_en,
    price: data.price,
    currency: data.currency as Currency,
    is_published: data.is_published,
    is_available: data.is_available,
    sort_order: data.sort_order,
    ...(imagePath !== undefined ? { image_path: imagePath } : {}),
  }

  if (data.id) {
    const { error } = await supabase.from('menu_items').update(payload).eq('id', data.id)
    return error ? { ok: false, error: error.message } : { ok: true, id: data.id }
  }
  const { data: row, error } = await supabase.from('menu_items').insert(payload).select('id').single()
  return error ? { ok: false, error: error.message } : { ok: true, id: row.id }
}

export async function deleteItem(id: unknown): Promise<ActionResult> {
  if (!(await requireOwner())) return UNAUTHORIZED
  if (typeof id !== 'string') return { ok: false, error: 'Invalid id' }
  const supabase = createClient()
  const { data: existing } = await supabase
    .from('menu_items')
    .select('image_path')
    .eq('id', id)
    .single()
  const { error } = await supabase.from('menu_items').delete().eq('id', id)
  if (!error && existing?.image_path) await removeImage(existing.image_path)
  return error ? { ok: false, error: error.message } : { ok: true }
}

// ---------- Settings / hours / appearance ----------

export async function saveSettings(input: SettingsInput): Promise<ActionResult> {
  if (!(await requireOwner())) return UNAUTHORIZED
  const parsed = settingsSchema.safeParse(input)
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message ?? 'Invalid input' }
  }
  const supabase = createClient()
  const rows = Object.entries(parsed.data).map(([key, value]) => ({
    key,
    value: JSON.stringify(value ?? ''),
  }))
  const { error } = await supabase
    .from('restaurant_settings')
    .upsert(rows, { onConflict: 'key' })
  return error ? { ok: false, error: error.message } : { ok: true }
}

export async function saveHeroImage(file: File | null): Promise<ActionResult> {
  if (!(await requireOwner())) return UNAUTHORIZED
  if (!file || file.size === 0) return { ok: false, error: 'Choose an image first' }
  const up = await uploadImage(file, 'site')
  if (up.error || !up.path) return { ok: false, error: up.error ?? 'Upload failed' }
  const supabase = createClient()
  const { error } = await supabase
    .from('restaurant_settings')
    .upsert({ key: 'hero_image', value: JSON.stringify(up.path) }, { onConflict: 'key' })
  return error ? { ok: false, error: error.message } : { ok: true }
}

export async function removeHeroImage(): Promise<ActionResult> {
  if (!(await requireOwner())) return UNAUTHORIZED
  const supabase = createClient()
  const { data } = await supabase
    .from('restaurant_settings')
    .select('value')
    .eq('key', 'hero_image')
    .maybeSingle()
  if (typeof data?.value === 'string') await removeImage(data.value)
  await supabase.from('restaurant_settings').delete().eq('key', 'hero_image')
  return { ok: true }
}

export async function saveHours(input: HoursInput): Promise<ActionResult> {
  if (!(await requireOwner())) return UNAUTHORIZED
  const parsed = hoursSchema.safeParse(input)
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message ?? 'Invalid input' }
  }
  const supabase = createClient()
  const rows = parsed.data.map((r) => ({
    day_of_week: r.day_of_week,
    is_closed: r.is_closed,
    open_time: r.is_closed ? null : r.open_time,
    close_time: r.is_closed ? null : r.close_time,
  }))
  const { error } = await supabase.from('opening_hours').upsert(rows, { onConflict: 'day_of_week' })
  return error ? { ok: false, error: error.message } : { ok: true }
}
