import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Overview' }

export default async function OwnerOverviewPage() {
  const supabase = createClient()
  const [items, categories, unpublished, images] = await Promise.all([
    supabase.from('menu_items').select('id', { count: 'exact', head: true }),
    supabase.from('categories').select('id', { count: 'exact', head: true }),
    supabase.from('menu_items').select('id', { count: 'exact', head: true }).eq('is_published', false),
    supabase.storage.from('menu-images').list('items', { limit: 100 }),
  ])

  const stats = [
    { label: 'Menu items', value: items.count ?? 0, href: '/owner/items' },
    { label: 'Categories', value: categories.count ?? 0, href: '/owner/categories' },
    { label: 'Hidden items', value: unpublished.count ?? 0, href: '/owner/items' },
    { label: 'Photos uploaded', value: images.data?.length ?? 0, href: '/owner/images' },
  ]

  return (
    <div>
      <h1 className="font-serif text-2xl text-ivory">Overview</h1>
      <p className="mt-1 text-sm text-muted">
        Changes are saved to the database and appear on the public menu immediately.
      </p>
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <Link
            key={s.label}
            href={s.href}
            className="rounded-2xl border border-ivory/10 bg-charcoal p-5 shadow-card transition hover:border-gold/40"
          >
            <p className="font-serif text-3xl text-gold">{s.value}</p>
            <p className="mt-1 text-sm text-muted">{s.label}</p>
          </Link>
        ))}
      </div>
      <div className="mt-8 rounded-2xl border border-ivory/10 bg-charcoal p-5">
        <h2 className="font-serif text-lg text-ivory">Public menu</h2>
        <p className="mt-1 text-sm text-muted">
          Customers scan the QR code and open the permanent menu URL. Print it once — the content
          updates itself.
        </p>
        <Link
          href="/menu"
          target="_blank"
          className="mt-4 inline-block rounded-full border border-gold/50 px-5 py-2 text-sm text-gold transition hover:bg-gold/10"
        >
          Open /menu
        </Link>
      </div>
    </div>
  )
}
