'use client'

import Link from 'next/link'

export interface ItemRow {
  id: string
  name: string
  category: string
  price: string
  published: boolean
  available: boolean
  hasRu: boolean
  hasEn: boolean
}

export function ItemsList({ rows }: { rows: ItemRow[] }) {
  if (rows.length === 0) {
    return (
      <div className="mt-6 rounded-2xl border border-dashed border-ivory/20 bg-charcoal p-10 text-center">
        <p className="font-serif text-lg text-ivory">No dishes yet</p>
        <p className="mt-1 text-sm text-muted">
          Add your first dish — only content you enter yourself will ever appear on the menu.
        </p>
        <Link
          href="/owner/items/new"
          className="mt-4 inline-block rounded-full bg-gold px-5 py-2 text-sm font-medium text-charcoal transition hover:bg-gold-bright"
        >
          + Add dish
        </Link>
      </div>
    )
  }
  return (
    <ul className="mt-6 space-y-2">
      {rows.map((row) => (
        <li
          key={row.id}
          className="flex flex-wrap items-center gap-x-4 gap-y-1 rounded-xl border border-ivory/10 bg-charcoal px-4 py-3"
        >
          <span className="min-w-0 flex-1 font-serif text-ivory">{row.name}</span>
          <span className="text-xs text-muted">{row.category}</span>
          <span className="text-sm text-gold">{row.price}</span>
          <span className={`text-xs ${row.published ? 'text-emerald-300' : 'text-muted'}`}>
            {row.published ? 'Published' : 'Hidden'}
          </span>
          <span className={`text-xs ${row.available ? 'text-emerald-300' : 'text-red-300'}`}>
            {row.available ? 'Available' : 'Unavailable'}
          </span>
          {(!row.hasRu || !row.hasEn) && (
            <span className="text-xs text-gold/70" title="Missing translations">
              {!row.hasRu && 'RU missing '}
              {!row.hasEn && 'EN missing'}
            </span>
          )}
          <Link
            href={`/owner/items/${row.id}`}
            className="rounded-full border border-ivory/15 px-4 py-1 text-xs text-ivory/80 transition hover:border-gold/50 hover:text-gold"
          >
            Edit
          </Link>
        </li>
      ))}
    </ul>
  )
}
