import { notFound } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { env } from '@/lib/env'
import { ItemForm } from '@/components/owner/ItemForm'
import type { MenuItemRow } from '@/types/database'

export const metadata = { title: 'Edit dish' }
export const dynamic = 'force-dynamic'

export default async function EditItemPage({ params }: { params: { id: string } }) {
  const supabase = createClient()
  const { data: item } = await supabase
    .from('menu_items')
    .select('*')
    .eq('id', params.id)
    .maybeSingle()
  const { data: categories } = await supabase.from('categories').select('id, name_uz').order('sort_order')

  if (!item) notFound()

  return (
    <div>
      <h1 className="font-serif text-2xl text-ivory">Edit dish</h1>
      <div className="mt-6">
        <ItemForm item={item as MenuItemRow} categories={categories ?? []} supabaseUrl={env.supabaseUrl} />
      </div>
    </div>
  )
}
