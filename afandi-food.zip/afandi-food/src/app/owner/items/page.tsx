import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { ItemsList } from './ItemsList'

export const metadata = { title: 'Menu items' }
export const dynamic = 'force-dynamic'

export default async function OwnerItemsPage() {
  const supabase = createClient()
  const { data: items } = await supabase
    .from('menu_items')
    .select('id, name_uz, name_ru, name_en, price, currency, is_published, is_available, sort_order, category_id, categories(name_uz)')
    .order('sort_order')
  const { data: categories } = await supabase.from('categories').select('id, name_uz').order('sort_order')

  const catName = new Map((categories ?? []).map((c) => [c.id as string, c.name_uz as string]))

  const rows = (items ?? []).map((i) => ({
    id: i.id as string,
    name: i.name_uz as string,
    category: (i.categories as { name_uz: string } | null)?.name_uz ?? (i.category_id ? '—' : 'No category'),
    price: i.price != null ? `${i.price} ${i.currency}` : '—',
    published: i.is_published as boolean,
    available: i.is_available as boolean,
    hasRu: Boolean(i.name_ru),
    hasEn: Boolean(i.name_en),
  }))

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-serif text-2xl text-ivory">Menu items</h1>
        <Link
          href="/owner/items/new"
          className="rounded-full bg-gold px-5 py-2 text-sm font-medium text-charcoal transition hover:bg-gold-bright"
        >
          + Add dish
        </Link>
      </div>
      <p className="mt-1 text-sm text-muted">
        Hidden (unpublished) dishes are visible only here, never to customers.
      </p>
      <ItemsList rows={rows} />
    </div>
  )
}
