import { createClient } from '@/lib/supabase/server'
import { env } from '@/lib/env'
import { ItemForm } from '@/components/owner/ItemForm'

export const metadata = { title: 'New dish' }
export const dynamic = 'force-dynamic'

export default async function NewItemPage() {
  const supabase = createClient()
  const { data: categories } = await supabase.from('categories').select('id, name_uz').order('sort_order')
  return (
    <div>
      <h1 className="font-serif text-2xl text-ivory">Add dish</h1>
      <p className="mt-1 text-sm text-muted">
        The dish stays hidden until you publish it.
      </p>
      <div className="mt-6">
        <ItemForm item={null} categories={categories ?? []} supabaseUrl={env.supabaseUrl} />
      </div>
    </div>
  )
}
