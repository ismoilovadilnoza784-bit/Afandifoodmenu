'use client'

import { useRouter } from 'next/navigation'
import { useState, useTransition } from 'react'
import { saveHeroImage } from '@/app/owner/actions'

export function ImageManager({ files, uploadHint }: { files: { path: string }[]; uploadHint: string }) {
  const router = useRouter()
  const [file, setFile] = useState<File | null>(null)
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null)
  const [pending, startTransition] = useTransition()

  function onUpload(e: React.FormEvent) {
    e.preventDefault()
    setMessage(null)
    if (!file) return
    startTransition(async () => {
      const result = await saveHeroImage(file)
      setMessage(
        result.ok
          ? { ok: true, text: 'Uploaded. It is now used as the site header photo.' }
          : { ok: false, text: result.error ?? 'Upload failed' },
      )
      if (result.ok) {
        setFile(null)
        router.refresh()
      }
    })
  }

  return (
    <form onSubmit={onUpload} className="rounded-2xl border border-ivory/10 bg-charcoal p-5">
      <h2 className="font-serif text-lg text-ivory">Header photo</h2>
      <p className="mt-1 text-sm text-muted">{uploadHint}</p>
      <div className="mt-3 flex flex-wrap items-center gap-4">
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp,image/avif"
          onChange={(e) => setFile(e.target.files?.[0] ?? null)}
          className="text-sm text-muted file:mr-3 file:rounded-full file:border-0 file:bg-gold file:px-4 file:py-1.5 file:text-xs file:text-charcoal"
        />
        <button
          type="submit"
          disabled={pending || !file}
          className="rounded-full bg-gold px-5 py-2 text-sm font-medium text-charcoal transition hover:bg-gold-bright disabled:opacity-50"
        >
          {pending ? 'Uploading…' : 'Upload as header photo'}
        </button>
      </div>
      {message && (
        <p
          role={message.ok ? 'status' : 'alert'}
          className={`mt-3 rounded-xl border px-4 py-2 text-sm ${
            message.ok
              ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300'
              : 'border-red-500/40 bg-red-500/10 text-red-300'
          }`}
        >
          {message.text}
        </p>
      )}
      <p className="mt-2 text-xs text-muted">Library: {files.length} file(s)</p>
    </form>
  )
}
