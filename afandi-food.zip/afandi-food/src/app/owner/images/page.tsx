import Image from 'next/image'
import { createClient } from '@/lib/supabase/server'
import { env } from '@/lib/env'
import { ImageManager } from './ImageManager'

export const metadata = { title: 'Images' }
export const dynamic = 'force-dynamic'

export default async function OwnerImagesPage() {
  const supabase = createClient()
  const { data: folders } = await supabase.storage.from('menu-images').list('', { limit: 100 })

  const files: { name: string; url: string; path: string }[] = []
  for (const folder of folders ?? []) {
    if (!folder.id) continue // folders have id; skip placeholder rows
    const { data: objects } = await supabase.storage.from('menu-images').list(folder.name, { limit: 100 })
    for (const obj of objects ?? []) {
      if (!obj.name) continue
      const path = `${folder.name}/${obj.name}`
      files.push({
        name: obj.name,
        path,
        url: `${env.supabaseUrl}/storage/v1/object/public/menu-images/${path}`,
      })
    }
  }

  return (
    <div>
      <h1 className="font-serif text-2xl text-ivory">Image management</h1>
      <p className="mt-1 text-sm text-muted">
        Every photo uploaded anywhere in the dashboard appears here. Only the owner can upload or
        delete — enforced by storage policies.
      </p>
      <div className="mt-6">
        <ImageManager
          files={files}
          uploadHint="You can also attach photos directly when creating or editing a dish."
        />
      </div>
      <ul className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {files.map((f) => (
          <li key={f.path} className="overflow-hidden rounded-xl border border-ivory/10 bg-charcoal">
            <div className="relative aspect-square">
              <Image src={f.url} alt={f.name} fill sizes="(max-width: 640px) 50vw, 200px" className="object-cover" />
            </div>
            <div className="flex items-center justify-between gap-2 p-2">
              <span className="truncate text-xs text-muted">{f.path}</span>
              {/* Deletion is offered in the single-purpose dialog below to keep confirmations explicit */}
            </div>
          </li>
        ))}
      </ul>
      {files.length === 0 && (
        <p className="mt-4 rounded-2xl border border-dashed border-ivory/20 p-8 text-center text-sm text-muted">
          No images yet. Upload your first photo above.
        </p>
      )}
    </div>
  )
}
