import { createClient } from '@/lib/supabase/server'
import { CategoriesManager, type CategoryRowView } from './CategoriesManager'

export const metadata = { title: 'Categories' }
export const dynamic = 'force-dynamic'

export default async function OwnerCategoriesPage() {
  const supabase = createClient()
  const { data: categories } = await supabase
    .from('categories')
    .select('id, name_uz, name_ru, name_en, slug, sort_order, is_published')
    .order('sort_order')
  const { data: counts } = await supabase
    .from('menu_items')
    .select('category_id')

  const countByCategory = new Map<string, number>()
  for (const row of counts ?? []) {
    const key = row.category_id as string | null
    if (key) countByCategory.set(key, (countByCategory.get(key) ?? 0) + 1)
  }

  const rows: CategoryRowView[] = (categories ?? []).map((c) => ({
    id: c.id as string,
    name_uz: c.name_uz as string,
    name_ru: (c.name_ru as string | null) ?? null,
    name_en: (c.name_en as string | null) ?? null,
    slug: c.slug as string,
    sort_order: c.sort_order as number,
    is_published: c.is_published as boolean,
    item_count: countByCategory.get(c.id as string) ?? 0,
  }))

  return (
    <div>
      <h1 className="font-serif text-2xl text-ivory">Categories</h1>
      <p className="mt-1 text-sm text-muted">
        Deleting a category never deletes its dishes — they remain in the menu without a category.
      </p>
      <CategoriesManager rows={rows} />
    </div>
  )
}
