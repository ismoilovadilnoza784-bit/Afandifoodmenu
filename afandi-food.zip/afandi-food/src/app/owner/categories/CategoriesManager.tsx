'use client'

import { useRouter } from 'next/navigation'
import { useState, useTransition } from 'react'
import { saveCategory, deleteCategory } from '@/app/owner/actions'
import { inputCls, labelCls, Feedback, DeleteButton, LocalizedFields } from '@/components/owner/ui'

export interface CategoryRowView {
  id: string
  name_uz: string
  name_ru: string | null
  name_en: string | null
  slug: string
  sort_order: number
  is_published: boolean
  item_count: number
}

export function CategoriesManager({ rows }: { rows: CategoryRowView[] }) {
  const router = useRouter()
  const [editing, setEditing] = useState<string | null>(null)
  const [creating, setCreating] = useState(false)
  return (
    <div className="mt-6 space-y-4">
      {rows.map((row) => (
        <div key={row.id} className="rounded-2xl border border-ivory/10 bg-charcoal p-5">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
            <span className="min-w-0 flex-1 font-serif text-ivory">{row.name_uz}</span>
            <span className="text-xs text-muted">/{row.slug}</span>
            <span className="text-xs text-muted">{row.item_count} dishes</span>
            <span className={`text-xs ${row.is_published ? 'text-emerald-300' : 'text-muted'}`}>
              {row.is_published ? 'Published' : 'Hidden'}
            </span>
            <button
              type="button"
              onClick={() => setEditing(editing === row.id ? null : row.id)}
              className="rounded-full border border-ivory/15 px-4 py-1 text-xs text-ivory/80 transition hover:border-gold/50 hover:text-gold"
            >
              {editing === row.id ? 'Close' : 'Edit'}
            </button>
          </div>
          {editing === row.id && (
            <CategoryForm
              row={row}
              onDone={() => {
                setEditing(null)
                router.refresh()
              }}
            />
          )}
        </div>
      ))}

      {creating ? (
        <CategoryForm
          row={null}
          onDone={() => {
            setCreating(false)
            router.refresh()
          }}
        />
      ) : (
        <button
          type="button"
          onClick={() => setCreating(true)}
          className="rounded-full bg-gold px-5 py-2 text-sm font-medium text-charcoal transition hover:bg-gold-bright"
        >
          + Add category
        </button>
      )}
    </div>
  )
}

function CategoryForm({ row, onDone }: { row: CategoryRowView | null; onDone: () => void }) {
  const router = useRouter()
  const [names, setNames] = useState({
    uz: row?.name_uz ?? '', ru: row?.name_ru ?? '', en: row?.name_en ?? '',
  })
  const [slug, setSlug] = useState(row?.slug ?? '')
  const [sortOrder, setSortOrder] = useState(String(row?.sort_order ?? 0))
  const [published, setPublished] = useState(row?.is_published ?? true)
  const [state, setState] = useState<{ ok: boolean; error?: string } | null>(null)
  const [pending, startTransition] = useTransition()

  function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setState(null)
    startTransition(async () => {
      const result = await saveCategory({
        id: row?.id,
        name_uz: names.uz,
        name_ru: names.ru,
        name_en: names.en,
        slug: slug || undefined,
        sort_order: sortOrder,
        is_published: published ? 'on' : '',
      })
      setState(result)
      if (result.ok) {
        onDone()
        router.refresh()
      }
    })
  }

  const itemCount = row?.item_count ?? 0

  return (
    <form onSubmit={onSubmit} className="mt-4 space-y-4 border-t border-ivory/10 pt-4">
      <Feedback state={state} />
      <LocalizedFields
        prefix="name"
        values={names}
        onChange={(lang, value) => setNames((prev) => ({ ...prev, [lang]: value }))}
        labels={{ uz: 'Name (Uzbek)', ru: 'Name (Russian)', en: 'Name (English)' }}
      />
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="slug" className={labelCls}>URL slug (optional)</label>
          <input
            id="slug"
            type="text"
            value={slug}
            onChange={(e) => setSlug(e.target.value)}
            placeholder="auto-generated from the Uzbek name"
            className={inputCls}
          />
        </div>
        <div>
          <label htmlFor="cat-sort" className={labelCls}>Display order</label>
          <input
            id="cat-sort"
            type="number"
            min={0}
            value={sortOrder}
            onChange={(e) => setSortOrder(e.target.value)}
            className={inputCls}
          />
        </div>
      </div>
      <label className="flex items-center gap-2 text-sm text-ivory/85">
        <input type="checkbox" checked={published} onChange={(e) => setPublished(e.target.checked)} className="accent-gold" />
        Published
      </label>
      <div className="flex items-center justify-between">
        <div className="flex gap-3">
          <button
            type="submit"
            disabled={pending}
            className="rounded-full bg-gold px-5 py-2 text-sm font-medium text-charcoal transition hover:bg-gold-bright disabled:opacity-60"
          >
            {pending ? 'Saving…' : row ? 'Save changes' : 'Create category'}
          </button>
          <button
            type="button"
            onClick={onDone}
            className="rounded-full border border-ivory/15 px-5 py-2 text-sm text-ivory/80 transition hover:border-gold/50 hover:text-gold"
          >
            Cancel
          </button>
        </div>
        {row && (
          <DeleteButton
            label="Delete category"
            confirmText={
              itemCount > 0
                ? `This category has ${itemCount} dish(es). Deleting it will NOT delete the dishes — they will stay in the menu without a category. Continue?`
                : 'Delete this category permanently?'
            }
            onDelete={async () => {
              const result = await deleteCategory(row.id)
              if (result.ok) router.refresh()
              return result
            }}
          />
        )}
      </div>
    </form>
  )
}
