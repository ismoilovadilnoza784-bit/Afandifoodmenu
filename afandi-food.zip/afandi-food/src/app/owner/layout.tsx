import Link from 'next/link'
import { redirect } from 'next/navigation'
import { requireOwner } from '@/lib/auth'
import { signOut } from './actions'

const NAV = [
  { href: '/owner', label: 'Overview', exact: true },
  { href: '/owner/items', label: 'Menu items' },
  { href: '/owner/categories', label: 'Categories' },
  { href: '/owner/images', label: 'Images' },
  { href: '/owner/settings', label: 'Restaurant info' },
  { href: '/owner/hours', label: 'Opening hours' },
  { href: '/owner/translations', label: 'Translations' },
  { href: '/owner/appearance', label: 'Appearance' },
  { href: '/owner/account', label: 'Account & security' },
] as const

function NavLink({ href, label, exact }: { href: string; label: string; exact?: boolean }) {
  return (
    <Link
      href={href}
      className="shrink-0 rounded-full border border-ivory/15 px-4 py-1.5 text-sm text-ivory/80 transition hover:border-gold/50 hover:text-gold"
      // active styling handled by server component below via usePathname alternative:
    >
      {label}
    </Link>
  )
}

export default async function OwnerLayout({ children }: { children: React.ReactNode }) {
  const owner = await requireOwner()
  if (!owner) redirect('/owner/login')

  return (
    <div className="min-h-screen bg-chardeep">
      <header className="sticky top-0 z-40 border-b border-ivory/8 bg-charcoal/95 backdrop-blur">
        <div className="mx-auto flex max-w-shell flex-wrap items-center justify-between gap-3 px-4 py-3">
          <Link href="/owner" className="font-serif text-lg text-ivory">
            Afandi Food <span className="text-xs uppercase tracking-widest text-gold">Owner</span>
          </Link>
          <form action={signOut}>
            <button
              type="submit"
              className="rounded-full border border-ivory/15 px-4 py-1.5 text-xs text-ivory/80 transition hover:border-red-400/60 hover:text-red-300"
            >
              Sign out
            </button>
          </form>
        </div>
        <nav
          aria-label="Owner dashboard"
          className="mx-auto flex max-w-shell gap-2 overflow-x-auto px-4 pb-3"
        >
          {NAV.map((item) => (
            <NavLink key={item.href} href={item.href} label={item.label} exact={'exact' in item} />
          ))}
        </nav>
      </header>
      <div className="mx-auto max-w-shell px-4 py-8">{children}</div>
    </div>
  )
}
