import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Translations' }
export const dynamic = 'force-dynamic'

export default async function OwnerTranslationsPage() {
  const supabase = createClient()
  const { data: items } = await supabase
    .from('menu_items')
    .select('id, name_uz, name_ru, name_en, description_ru, description_en')
    .order('name_uz')
  const { data: categories } = await supabase
    .from('categories')
    .select('id, name_uz, name_ru, name_en')
    .order('sort_order')

  const itemsMissing = (items ?? []).filter(
    (i) => !i.name_ru || !i.name_en || !i.description_ru || !i.description_en,
  )
  const categoriesMissing = (categories ?? []).filter((c) => !c.name_ru || !c.name_en)

  return (
    <div>
      <h1 className="font-serif text-2xl text-ivory">Language & translations</h1>
      <div className="mt-4 max-w-2xl rounded-2xl border border-ivory/10 bg-charcoal p-5">
        <h2 className="font-serif text-lg text-ivory">How languages work</h2>
        <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-ivory-dim">
          <li>The menu is available in Uzbek (default), Russian and English.</li>
          <li>Dish names, descriptions and categories each have separate Uzbek / Russian / English fields.</li>
          <li>If a translation is missing, the menu falls back: your language → Uzbek → Russian → English.</li>
          <li>Nothing is ever machine-translated or invented for you — only what you enter is shown.</li>
          <li>Interface buttons and messages are translated automatically by the platform.</li>
        </ul>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <section className="rounded-2xl border border-ivory/10 bg-charcoal p-5">
          <h2 className="font-serif text-lg text-ivory">Dishes missing translations</h2>
          {itemsMissing.length === 0 ? (
            <p className="mt-2 text-sm text-emerald-300">
              All {(items ?? []).length} dishes have Russian and English names and descriptions. 
            </p>
          ) : (
            <ul className="mt-3 space-y-2">
              {itemsMissing.map((i) => (
                <li key={i.id} className="flex items-center justify-between gap-3 rounded-xl border border-ivory/10 bg-charcoal-soft px-4 py-2">
                  <span className="min-w-0 flex-1 truncate text-sm text-ivory">{i.name_uz as string}</span>
                  <span className="text-xs text-gold/80">
                    {!i.name_ru && 'RU name '}
                    {!i.name_en && 'EN name '}
                    {!i.description_ru && 'RU desc '}
                    {!i.description_en && 'EN desc'}
                  </span>
                  <Link
                    href={`/owner/items/${i.id}`}
                    className="shrink-0 rounded-full border border-ivory/15 px-3 py-1 text-xs text-ivory/80 transition hover:border-gold/50 hover:text-gold"
                  >
                    Translate
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="rounded-2xl border border-ivory/10 bg-charcoal p-5">
          <h2 className="font-serif text-lg text-ivory">Categories missing translations</h2>
          {categoriesMissing.length === 0 ? (
            <p className="mt-2 text-sm text-emerald-300">All categories are fully translated.</p>
          ) : (
            <ul className="mt-3 space-y-2">
              {categoriesMissing.map((c) => (
                <li key={c.id} className="flex items-center justify-between gap-3 rounded-xl border border-ivory/10 bg-charcoal-soft px-4 py-2">
                  <span className="min-w-0 flex-1 truncate text-sm text-ivory">{c.name_uz as string}</span>
                  <span className="text-xs text-gold/80">
                    {!c.name_ru && 'RU '}
                    {!c.name_en && 'EN'}
                  </span>
                  <Link
                    href="/owner/categories"
                    className="shrink-0 rounded-full border border-ivory/15 px-3 py-1 text-xs text-ivory/80 transition hover:border-gold/50 hover:text-gold"
                  >
                    Translate
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  )
}
