export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface ProfileRow {
  id: string
  display_name: string | null
  created_at: string
}

export interface UserRoleRow {
  user_id: string
  role: 'owner'
  created_at: string
}

export interface CategoryRow {
  id: string
  name_uz: string
  name_ru: string | null
  name_en: string | null
  slug: string
  sort_order: number
  is_published: boolean
  created_at: string
  updated_at: string
}

export type Currency = 'UZS' | 'USD' | 'EUR' | 'RUB'

export interface MenuItemRow {
  id: string
  category_id: string | null
  name_uz: string
  name_ru: string | null
  name_en: string | null
  description_uz: string | null
  description_ru: string | null
  description_en: string | null
  price: number | null
  currency: Currency
  image_path: string | null
  is_published: boolean
  is_available: boolean
  sort_order: number
  created_at: string
  updated_at: string
}

export interface SettingRow {
  key: string
  value: Json
  updated_at: string
}

export interface OpeningHoursRow {
  id: string
  day_of_week: number // 0 = Monday ... 6 = Sunday
  open_time: string | null
  close_time: string | null
  is_closed: boolean
}
