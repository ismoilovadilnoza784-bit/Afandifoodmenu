'use client'

import { useRouter } from 'next/navigation'
import { useTransition } from 'react'
import { setLanguage } from '@/app/menu/actions'
import { LANGS, type Lang } from '@/lib/i18n'
import { cn } from '@/lib/utils'

export function LanguageSwitcher({ lang }: { lang: Lang }) {
  const router = useRouter()
  const [pending, startTransition] = useTransition()

  function choose(next: Lang) {
    if (next === lang) return
    startTransition(async () => {
      await setLanguage(next)
      router.refresh()
    })
  }

  return (
    <div
      className="flex rounded-full border border-ivory/15 p-0.5"
      role="group"
      aria-label="Language / Til / Язык"
    >
      {LANGS.map((l) => (
        <button
          key={l}
          type="button"
          disabled={pending}
          onClick={() => choose(l)}
          aria-pressed={l === lang}
          className={cn(
            'rounded-full px-3 py-1 text-xs uppercase tracking-wide transition',
            l === lang ? 'bg-gold text-charcoal' : 'text-ivory/70 hover:text-ivory',
          )}
        >
          {l}
        </button>
      ))}
    </div>
  )
}
