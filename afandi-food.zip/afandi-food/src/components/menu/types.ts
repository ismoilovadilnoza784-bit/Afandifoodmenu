export interface CategoryView {
  id: string
  slug: string
  name: string
}

export interface DishView {
  id: string
  category_id: string | null
  name: string
  description: string
  price: string | null // pre-formatted for the active language
  rawPrice: number | null
  currency: string
  imageUrl: string | null
  is_available: boolean
  sort_order: number
}
