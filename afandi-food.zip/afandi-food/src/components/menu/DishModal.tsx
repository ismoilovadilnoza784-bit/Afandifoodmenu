'use client'

import Image from 'next/image'
import { useEffect, useRef } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import type { Dictionary } from '@/lib/i18n/dictionaries'
import type { DishView } from './types'

export function DishModal({ items, t }: { items: DishView[]; t: Dictionary }) {
  const router = useRouter()
  const params = useSearchParams()
  const closeRef = useRef<HTMLButtonElement>(null)
  const dishId = params.get('dish')
  const dish = items.find((i) => i.id === dishId) ?? null

  useEffect(() => {
    if (!dish) return
    closeRef.current?.focus()
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') close()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [dish])

  function close() {
    const next = new URLSearchParams(params.toString())
    next.delete('dish')
    router.replace(`/menu?${next.toString()}`, { scroll: false })
  }

  if (!dish) return null

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-0 sm:items-center sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label={dish.name}
      onClick={close}
    >
      <div
        className="w-full max-w-lg overflow-hidden rounded-t-2xl border border-ivory/10 bg-charcoal-soft shadow-card sm:rounded-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {dish.imageUrl && (
          <div className="relative aspect-[16/10] w-full">
            <Image
              src={dish.imageUrl}
              alt={dish.name}
              fill
              sizes="(max-width: 640px) 100vw, 32rem"
              className="object-cover"
              priority
            />
          </div>
        )}
        <div className="p-6">
          <div className="flex items-start justify-between gap-4">
            <h2 className="font-serif text-2xl text-ivory">{dish.name}</h2>
            {dish.price && (
              <p className="whitespace-nowrap font-serif text-lg text-gold">{dish.price}</p>
            )}
          </div>
          {!dish.is_available && (
            <p className="mt-2 inline-block rounded-full border border-gold/40 px-3 py-0.5 text-xs uppercase tracking-wide text-gold">
              {t.unavailable}
            </p>
          )}
          {dish.description ? (
            <p className="mt-3 leading-relaxed text-ivory-dim">{dish.description}</p>
          ) : null}
          <button
            ref={closeRef}
            onClick={close}
            className="mt-6 w-full rounded-full border border-ivory/20 py-2 text-sm text-ivory transition hover:border-gold/60 hover:text-gold"
          >
            {t.a11yClose}
          </button>
        </div>
      </div>
    </div>
  )
}
