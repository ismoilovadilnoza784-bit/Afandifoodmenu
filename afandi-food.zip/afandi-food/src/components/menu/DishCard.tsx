'use client'

import Image from 'next/image'
import type { Dictionary } from '@/lib/i18n/dictionaries'
import type { DishView } from './types'

export function DishCard({
  dish,
  t,
  onOpen,
}: {
  dish: DishView
  t: Dictionary
  onOpen: (id: string) => void
}) {
  return (
    <button
      type="button"
      onClick={() => onOpen(dish.id)}
      aria-label={`${dish.name} — ${t.a11yClose === 'Yopish' ? 'ochish' : 'open'}`}
      className="group flex w-full gap-4 rounded-2xl border border-ivory/8 bg-charcoal-soft p-4 text-left shadow-card transition hover:border-gold/40 focus:outline-none focus-visible:ring-2 focus-visible:ring-gold"
    >
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline justify-between gap-3">
          <h3 className="font-serif text-lg leading-snug text-ivory transition group-hover:text-gold-bright">
            {dish.name}
          </h3>
          {dish.price && (
            <span className="whitespace-nowrap font-serif text-base text-gold">{dish.price}</span>
          )}
        </div>
        {dish.description && (
          <p className="mt-1 line-clamp-2 text-sm leading-relaxed text-muted">{dish.description}</p>
        )}
        {!dish.is_available && (
          <span className="mt-2 inline-block rounded-full border border-gold/40 px-2.5 py-0.5 text-[11px] uppercase tracking-wide text-gold">
            {t.unavailable}
          </span>
        )}
      </div>
      {dish.imageUrl && (
        <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-xl border border-ivory/10">
          <Image
            src={dish.imageUrl}
            alt={dish.name}
            fill
            sizes="80px"
            className="object-cover transition duration-300 group-hover:scale-105"
          />
        </div>
      )}
    </button>
  )
}
