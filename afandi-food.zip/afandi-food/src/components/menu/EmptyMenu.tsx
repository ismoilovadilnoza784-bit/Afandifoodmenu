import { dict, type Lang } from '@/lib/i18n'

export function EmptyMenu({ lang, name }: { lang: Lang; name: string }) {
  const t = dict(lang)
  return (
    <div className="mx-auto max-w-md px-6 py-24 text-center">
      <p className="font-serif text-4xl text-gold">A</p>
      <h2 className="mt-4 font-serif text-2xl text-ivory">{name}</h2>
      <p className="mt-2 font-serif text-lg text-muted">{t.emptyTitle}</p>
      <p className="mt-4 text-sm leading-relaxed text-muted">{t.emptyText}</p>
    </div>
  )
}
