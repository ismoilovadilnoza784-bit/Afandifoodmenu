'use client'

import { Suspense, useMemo, useState } from 'react'
import { useRouter, useSearchParams, usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import type { Dictionary } from '@/lib/i18n/dictionaries'
import type { CategoryView, DishView } from './types'
import { DishCard } from './DishCard'
import { DishModal } from './DishModal'

function MenuInner({
  categories,
  items,
  t,
}: {
  categories: CategoryView[]
  items: DishView[]
  t: Dictionary
}) {
  const router = useRouter()
  const pathname = usePathname()
  const params = useSearchParams()
  const [query, setQuery] = useState('')

  const activeSlug = params.get('category') ?? 'all'
  const activeCategory = categories.find((c) => c.slug === activeSlug) ?? null

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase()
    return items.filter((dish) => {
      if (activeCategory && dish.category_id !== activeCategory.id) return false
      if (!q) return true
      return dish.name.toLowerCase().includes(q) || dish.description.toLowerCase().includes(q)
    })
  }, [items, activeCategory, query])

  function setCategory(slug: string | null) {
    const next = new URLSearchParams(params.toString())
    if (slug) next.set('category', slug)
    else next.delete('category')
    next.delete('dish')
    router.replace(`${pathname}?${next.toString()}`, { scroll: false })
  }

  function openDish(id: string) {
    const next = new URLSearchParams(params.toString())
    next.set('dish', id)
    router.replace(`${pathname}?${next.toString()}`, { scroll: false })
  }

  return (
    <>
      <div className="sticky top-0 z-30 border-b border-ivory/8 bg-charcoal/90 backdrop-blur">
        <div className="mx-auto max-w-shell px-4 py-3">
          <label className="sr-only" htmlFor="menu-search">
            {t.searchPlaceholder}
          </label>
          <input
            id="menu-search"
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-full rounded-full border border-ivory/15 bg-charcoal-soft px-4 py-2.5 text-sm text-ivory placeholder:text-muted focus:border-gold/60 focus:outline-none"
          />
          {categories.length > 0 && (
            <nav aria-label="Categories" className="mt-3 flex gap-2 overflow-x-auto pb-1">
              <button
                type="button"
                onClick={() => setCategory(null)}
                aria-pressed={!activeCategory}
                className={cn(
                  'shrink-0 rounded-full border px-4 py-1.5 text-sm transition',
                  !activeCategory
                    ? 'border-gold bg-gold text-charcoal'
                    : 'border-ivory/15 text-ivory/80 hover:border-gold/50 hover:text-gold',
                )}
              >
                {t.allCategories}
              </button>
              {categories.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setCategory(c.slug)}
                  aria-pressed={activeCategory?.id === c.id}
                  className={cn(
                    'shrink-0 rounded-full border px-4 py-1.5 text-sm transition',
                    activeCategory?.id === c.id
                      ? 'border-gold bg-gold text-charcoal'
                      : 'border-ivory/15 text-ivory/80 hover:border-gold/50 hover:text-gold',
                  )}
                >
                  {c.name}
                </button>
              ))}
            </nav>
          )}
        </div>
      </div>

      <section className="mx-auto max-w-shell px-4 py-6" aria-live="polite">
        {items.length === 0 ? null : visible.length === 0 ? (
          <p className="py-16 text-center text-muted">{t.noResults}</p>
        ) : (
          <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {visible.map((dish) => (
              <li key={dish.id}>
                <DishCard dish={dish} t={t} onOpen={openDish} />
              </li>
            ))}
          </ul>
        )}
      </section>

      <DishModal items={items} t={t} />
    </>
  )
}

export function MenuClient(props: {
  categories: CategoryView[]
  items: DishView[]
  t: Dictionary
}) {
  return (
    <Suspense fallback={<div className="py-16 text-center text-muted">…</div>}>
      <MenuInner {...props} />
    </Suspense>
  )
}
