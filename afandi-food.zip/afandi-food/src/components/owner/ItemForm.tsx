'use client'

import Image from 'next/image'
import { useRouter } from 'next/navigation'
import { useState, useTransition } from 'react'
import { saveItem, deleteItem } from '@/app/owner/actions'
import { inputCls, labelCls, Feedback, DeleteButton, LocalizedFields } from './ui'
import type { CategoryRow, Currency, MenuItemRow } from '@/types/database'

const EMPTY = {
  name_uz: '', name_ru: '', name_en: '',
  description_uz: '', description_ru: '', description_en: '',
}

export function ItemForm({
  item,
  categories,
  supabaseUrl,
}: {
  item: MenuItemRow | null
  categories: Pick<CategoryRow, 'id' | 'name_uz'>[]
  supabaseUrl: string
}) {
  const router = useRouter()
  const [names, setNames] = useState({
    uz: item?.name_uz ?? '', ru: item?.name_ru ?? '', en: item?.name_en ?? '',
  })
  const [descriptions, setDescriptions] = useState({
    uz: item?.description_uz ?? '', ru: item?.description_ru ?? '', en: item?.description_en ?? '',
  })
  const [categoryId, setCategoryId] = useState(item?.category_id ?? '')
  const [price, setPrice] = useState(item?.price != null ? String(item.price) : '')
  const [currency, setCurrency] = useState<Currency>(item?.currency ?? 'UZS')
  const [sortOrder, setSortOrder] = useState(String(item?.sort_order ?? 0))
  const [published, setPublished] = useState(item?.is_published ?? false)
  const [available, setAvailable] = useState(item?.is_available ?? true)
  const [removeImage, setRemoveImage] = useState(false)
  const [file, setFile] = useState<File | null>(null)
  const [clientError, setClientError] = useState<string | null>(null)
  const [state, setState] = useState<{ ok: boolean; error?: string } | null>(null)
  const [pending, startTransition] = useTransition()

  const currentImage =
    item?.image_path && !removeImage
      ? `${supabaseUrl}/storage/v1/object/public/menu-images/${item.image_path}`
      : null

  function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setClientError(null)
    setState(null)
    if (!names.uz.trim()) {
      setClientError('Name (Uzbek) is required')
      return
    }
    startTransition(async () => {
      const result = await saveItem(
        {
          id: item?.id,
          category_id: categoryId || null,
          name_uz: names.uz,
          name_ru: names.ru,
          name_en: names.en,
          description_uz: descriptions.uz,
          description_ru: descriptions.ru,
          description_en: descriptions.en,
          price,
          currency,
          is_published: published ? 'on' : '',
          is_available: available ? 'on' : '',
          sort_order: sortOrder,
          remove_image: removeImage ? 'on' : '',
        },
        file,
      )
      setState(result)
      if (result.ok) router.refresh()
    })
  }

  return (
    <form onSubmit={onSubmit} className="space-y-6">
      <Feedback state={state} />
      {clientError && (
        <p role="alert" className="rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-2 text-sm text-red-300">
          {clientError}
        </p>
      )}

      <section className="rounded-2xl border border-ivory/10 bg-charcoal p-5">
        <h2 className="font-serif text-lg text-ivory">Names</h2>
        <div className="mt-3">
          <LocalizedFields
            prefix="name"
            values={names}
            onChange={(lang, value) => setNames((prev) => ({ ...prev, [lang]: value }))}
            labels={{ uz: 'Name (Uzbek)', ru: 'Name (Russian)', en: 'Name (English)' }}
          />
        </div>
      </section>

      <section className="rounded-2xl border border-ivory/10 bg-charcoal p-5">
        <h2 className="font-serif text-lg text-ivory">Descriptions</h2>
        <div className="mt-3">
          <LocalizedFields
            prefix="description"
            values={descriptions}
            multiline
            onChange={(lang, value) => setDescriptions((prev) => ({ ...prev, [lang]: value }))}
            labels={{ uz: 'Description (Uzbek)', ru: 'Description (Russian)', en: 'Description (English)' }}
          />
        </div>
      </section>

      <section className="grid gap-4 rounded-2xl border border-ivory/10 bg-charcoal p-5 sm:grid-cols-2">
        <div>
          <label htmlFor="category" className={labelCls}>Category</label>
          <select
            id="category"
            value={categoryId}
            onChange={(e) => setCategoryId(e.target.value)}
            className={inputCls}
          >
            <option value="">— No category —</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>{c.name_uz}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="sort" className={labelCls}>Display order</label>
          <input
            id="sort"
            type="number"
            min={0}
            value={sortOrder}
            onChange={(e) => setSortOrder(e.target.value)}
            className={inputCls}
          />
        </div>
        <div>
          <label htmlFor="price" className={labelCls}>Price (optional)</label>
          <input
            id="price"
            type="number"
            min={0}
            step="0.01"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            className={inputCls}
          />
        </div>
        <div>
          <label htmlFor="currency" className={labelCls}>Currency</label>
          <select
            id="currency"
            value={currency}
            onChange={(e) => setCurrency(e.target.value as Currency)}
            className={inputCls}
          >
            {['UZS', 'USD', 'EUR', 'RUB'].map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
      </section>

      <section className="rounded-2xl border border-ivory/10 bg-charcoal p-5">
        <h2 className="font-serif text-lg text-ivory">Photo</h2>
        <div className="mt-3 flex items-start gap-4">
          {currentImage ? (
            <div className="relative h-24 w-24 overflow-hidden rounded-xl border border-ivory/10">
              <Image src={currentImage} alt="Current dish" fill sizes="96px" className="object-cover" />
            </div>
          ) : (
            <div className="flex h-24 w-24 items-center justify-center rounded-xl border border-dashed border-ivory/20 text-xs text-muted">
              No photo
            </div>
          )}
          <div className="space-y-2">
            <input
              id="image"
              type="file"
              accept="image/jpeg,image/png,image/webp,image/avif"
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
              className="text-sm text-muted file:mr-3 file:rounded-full file:border-0 file:bg-gold file:px-4 file:py-1.5 file:text-xs file:text-charcoal"
            />
            <p className="text-xs text-muted">JPEG, PNG, WebP or AVIF, max 5 MB.</p>
            {item?.image_path && (
              <label className="flex items-center gap-2 text-xs text-ivory/70">
                <input
                  type="checkbox"
                  checked={removeImage}
                  onChange={(e) => setRemoveImage(e.target.checked)}
                  className="accent-gold"
                />
                Remove current photo
              </label>
            )}
          </div>
        </div>
      </section>

      <section className="flex flex-wrap items-center gap-6 rounded-2xl border border-ivory/10 bg-charcoal p-5">
        <label className="flex items-center gap-2 text-sm text-ivory/85">
          <input
            type="checkbox"
            checked={published}
            onChange={(e) => setPublished(e.target.checked)}
            className="accent-gold"
          />
          Published (visible on the public menu)
        </label>
        <label className="flex items-center gap-2 text-sm text-ivory/85">
          <input
            type="checkbox"
            checked={available}
            onChange={(e) => setAvailable(e.target.checked)}
            className="accent-gold"
          />
          Available (in stock)
        </label>
      </section>

      <div className="flex items-center justify-between">
        <div className="flex gap-3">
          <button
            type="submit"
            disabled={pending}
            className="rounded-full bg-gold px-6 py-2.5 text-sm font-medium text-charcoal transition hover:bg-gold-bright disabled:opacity-60"
          >
            {pending ? 'Saving…' : item ? 'Save changes' : 'Create dish'}
          </button>
          <button
            type="button"
            onClick={() => router.push('/owner/items')}
            className="rounded-full border border-ivory/15 px-6 py-2.5 text-sm text-ivory/80 transition hover:border-gold/50 hover:text-gold"
          >
            Cancel
          </button>
        </div>
        {item && (
          <DeleteButton
            label="Delete dish"
            confirmText="Delete this dish permanently? This cannot be undone."
            onDelete={async () => {
              const result = await deleteItem(item.id)
              if (result.ok) router.push('/owner/items')
              return result
            }}
          />
        )}
      </div>
    </form>
  )
}
