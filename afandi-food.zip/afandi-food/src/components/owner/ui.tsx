'use client'

import { useState, useTransition } from 'react'
import { cn } from '@/lib/utils'

export const inputCls =
  'w-full rounded-xl border border-ivory/15 bg-charcoal-soft px-4 py-2.5 text-sm text-ivory placeholder:text-muted focus:border-gold/60 focus:outline-none'
export const labelCls = 'mb-1 block text-xs uppercase tracking-widest text-muted'

export function Feedback({ state }: { state: { ok: boolean; error?: string } | null }) {
  if (!state) return null
  return state.ok ? (
    <p role="status" className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-2 text-sm text-emerald-300">
      Saved.
    </p>
  ) : (
    <p role="alert" className="rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-2 text-sm text-red-300">
      {state.error ?? 'Something went wrong'}
    </p>
  )
}

export function SubmitButton({ label, pendingLabel = 'Saving…' }: { label: string; pendingLabel?: string }) {
  const [pending, startTransition] = useTransition()
  return (
    <button
      type="submit"
      disabled={pending}
      className={cn(
        'rounded-full bg-gold px-6 py-2.5 text-sm font-medium text-charcoal transition',
        pending ? 'opacity-60' : 'hover:bg-gold-bright',
      )}
    >
      {pending ? pendingLabel : label}
    </button>
  )
}

export function DeleteButton({
  label,
  confirmText,
  onDelete,
}: {
  label: string
  confirmText: string
  onDelete: () => Promise<{ ok: boolean; error?: string }>
}) {
  const [error, setError] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()

  function handle() {
    if (!window.confirm(confirmText)) return
    setError(null)
    startTransition(async () => {
      const result = await onDelete()
      if (!result.ok) setError(result.error ?? 'Delete failed')
    })
  }

  return (
    <span className="inline-flex flex-col items-start gap-1">
      <button
        type="button"
        onClick={handle}
        disabled={pending}
        className={cn(
          'rounded-full border px-4 py-1.5 text-xs transition',
          pending
            ? 'border-ivory/15 text-muted'
            : 'border-red-400/50 text-red-300 hover:bg-red-500/10',
        )}
      >
        {pending ? '…' : label}
      </button>
      {error && <span className="text-xs text-red-300">{error}</span>}
    </span>
  )
}

export function LocalizedFields({
  prefix,
  values,
  onChange,
  multiline = false,
  labels,
}: {
  prefix: 'name' | 'description' | 'tagline'
  values: { uz: string; ru: string; en: string }
  onChange: (lang: 'uz' | 'ru' | 'en', value: string) => void
  multiline?: boolean
  labels: { uz: string; ru: string; en: string }
}) {
  const langs = ['uz', 'ru', 'en'] as const
  return (
    <div className="space-y-3">
      {langs.map((lang) => (
        <div key={lang}>
          <label htmlFor={`${prefix}-${lang}`} className={labelCls}>
            {labels[lang]} {lang === 'uz' ? '*' : ''}
          </label>
          {multiline ? (
            <textarea
              id={`${prefix}-${lang}`}
              rows={3}
              value={values[lang]}
              onChange={(e) => onChange(lang, e.target.value)}
              className={inputCls}
            />
          ) : (
            <input
              id={`${prefix}-${lang}`}
              type="text"
              value={values[lang]}
              onChange={(e) => onChange(lang, e.target.value)}
              className={inputCls}
            />
          )}
        </div>
      ))}
    </div>
  )
}
