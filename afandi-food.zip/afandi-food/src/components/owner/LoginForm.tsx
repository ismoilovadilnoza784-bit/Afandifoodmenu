'use client'

import { useRouter } from 'next/navigation'
import { useState, useTransition } from 'react'
import { signIn, sendPasswordReset } from '@/app/owner/actions'
import { cn } from '@/lib/utils'

export interface LoginLabels {
  email: string
  password: string
  submit: string
  forgot: string
  invalid: string
  resetSent: string
}

const inputCls =
  'w-full rounded-xl border border-ivory/15 bg-charcoal-soft px-4 py-2.5 text-sm text-ivory placeholder:text-muted focus:border-gold/60 focus:outline-none'

export function LoginForm({ labels }: { labels: LoginLabels }) {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [notice, setNotice] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()

  function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setNotice(null)
    startTransition(async () => {
      const form = new FormData()
      form.set('email', email)
      form.set('password', password)
      const result = await signIn(form)
      if (result.ok) {
        router.push('/owner')
        router.refresh()
      } else {
        setPassword('')
        setError(labels.invalid)
      }
    })
  }

  function onReset() {
    setError(null)
    setNotice(null)
    startTransition(async () => {
      await sendPasswordReset(email)
      setNotice(labels.resetSent)
    })
  }

  return (
    <form onSubmit={onSubmit} className="mt-6 space-y-4">
      <div>
        <label htmlFor="email" className="mb-1 block text-xs uppercase tracking-widest text-muted">
          {labels.email}
        </label>
        <input
          id="email"
          type="email"
          required
          autoComplete="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className={inputCls}
        />
      </div>
      <div>
        <label htmlFor="password" className="mb-1 block text-xs uppercase tracking-widest text-muted">
          {labels.password}
        </label>
        <input
          id="password"
          type="password"
          required
          autoComplete="current-password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className={inputCls}
        />
      </div>
      {error && (
        <p role="alert" className="rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-2 text-sm text-red-300">
          {error}
        </p>
      )}
      {notice && (
        <p role="status" className="rounded-xl border border-gold/40 bg-gold/10 px-4 py-2 text-sm text-gold-bright">
          {notice}
        </p>
      )}
      <button
        type="submit"
        disabled={pending}
        className={cn(
          'w-full rounded-full bg-gold py-2.5 text-sm font-medium text-charcoal transition',
          pending ? 'opacity-60' : 'hover:bg-gold-bright',
        )}
      >
        {pending ? '…' : labels.submit}
      </button>
      <button
        type="button"
        onClick={onReset}
        disabled={pending || !email}
        className="w-full text-center text-xs text-muted transition hover:text-gold disabled:opacity-50"
      >
        {labels.forgot}
      </button>
    </form>
  )
}
