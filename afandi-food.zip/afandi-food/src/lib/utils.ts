import type { Lang } from '@/lib/i18n'
import { LOCALE } from '@/lib/i18n'

export function cn(...classes: Array<string | false | null | undefined>): string {
  return classes.filter(Boolean).join(' ')
}

const CHAR_MAP: Record<string, string> = {
  oʻ: 'o', gʻ: 'g', sh: 'sh', ch: 'ch', ng: 'ng',
  а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'yo', ж: 'zh',
  з: 'z', и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o',
  п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'kh', ц: 'ts',
  ч: 'ch', ш: 'sh', щ: 'shch', ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya',
}

export function slugify(input: string): string {
  let s = input.trim().toLowerCase()
  for (const [from, to] of Object.entries(CHAR_MAP)) s = s.split(from).join(to)
  return s
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80)
}

export function formatPrice(
  price: number | null,
  currency: string,
  lang: Lang,
): string | null {
  if (price === null || Number.isNaN(price)) return null
  const formatted = new Intl.NumberFormat(LOCALE[lang], {
    style: 'currency',
    currency,
    maximumFractionDigits: currency === 'UZS' ? 0 : 2,
  }).format(price)
  return formatted
}

export function storagePublicUrl(supabaseUrl: string, path: string): string {
  return `${supabaseUrl}/storage/v1/object/public/menu-images/${path}`
}

export function dayName(dayOfWeek: number, lang: Lang): string {
  const date = new Date(Date.UTC(2024, 0, 1 + dayOfWeek)) // 2024-01-01 is a Monday
  return new Intl.DateTimeFormat(LOCALE[lang], { weekday: 'long', timeZone: 'UTC' }).format(date)
}

export function formatTime(hhmm: string | null, lang: Lang): string {
  if (!hhmm) return ''
  const [h, m] = hhmm.split(':').map(Number)
  return new Intl.DateTimeFormat(LOCALE[lang], {
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'UTC',
  }).format(new Date(Date.UTC(2024, 0, 1, h, m)))
}
