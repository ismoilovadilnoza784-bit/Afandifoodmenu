import { z } from 'zod'

const optString = (max: number) =>
  z
    .string()
    .trim()
    .max(max, `Must be at most ${max} characters`)
    .transform((v) => (v === '' ? null : v))

const checkbox = z.preprocess(
  (v) => v === 'on' || v === 'true' || v === true,
  z.boolean(),
)

export const menuItemSchema = z.object({
  id: z.string().uuid().optional(),
  category_id: z
    .string()
    .uuid()
    .nullable()
    .optional()
    .transform((v) => v ?? null),
  name_uz: z.string().trim().min(1, 'Name (Uzbek) is required').max(160),
  name_ru: optString(160),
  name_en: optString(160),
  description_uz: optString(2000),
  description_ru: optString(2000),
  description_en: optString(2000),
  price: z.preprocess(
    (v) => (v === '' || v === null || v === undefined ? null : Number(v)),
    z
      .number({ invalid_type_error: 'Price must be a number' })
      .nonnegative('Price cannot be negative')
      .max(99999999, 'Price is too large')
      .nullable(),
  ),
  currency: z.enum(['UZS', 'USD', 'EUR', 'RUB']).default('UZS'),
  is_published: checkbox,
  is_available: checkbox,
  sort_order: z.coerce.number().int().min(0).max(9999).default(0),
  remove_image: checkbox.optional().default(false),
})
export type MenuItemInput = z.infer<typeof menuItemSchema>

export const categorySchema = z.object({
  id: z.string().uuid().optional(),
  name_uz: z.string().trim().min(1, 'Name (Uzbek) is required').max(120),
  name_ru: optString(120),
  name_en: optString(120),
  slug: z
    .string()
    .trim()
    .max(80)
    .regex(/^[a-z0-9-]*$/, 'Slug: lowercase letters, numbers and dashes only')
    .transform((v) => (v === '' ? null : v))
    .nullable()
    .optional(),
  sort_order: z.coerce.number().int().min(0).max(9999).default(0),
  is_published: checkbox,
})
export type CategoryInput = z.infer<typeof categorySchema>

export const settingKeys = [
  'name',
  'tagline_uz',
  'tagline_ru',
  'tagline_en',
  'address',
  'phone',
] as const
export type SettingKey = (typeof settingKeys)[number]

export const settingsSchema = z.object({
  name: z.string().trim().min(1).max(120),
  tagline_uz: optString(200),
  tagline_ru: optString(200),
  tagline_en: optString(200),
  address: optString(300),
  phone: optString(40),
})
export type SettingsInput = z.infer<typeof settingsSchema>

export const hourRowSchema = z.object({
  day_of_week: z.coerce.number().int().min(0).max(6),
  is_closed: checkbox,
  open_time: optString(5).transform((v) => v ?? null),
  close_time: optString(5).transform((v) => v ?? null),
})
export const hoursSchema = z
  .array(hourRowSchema)
  .length(7)
  .superRefine((rows, ctx) => {
    for (const row of rows) {
      if (!row.is_closed && (!row.open_time || !row.close_time)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Day ${row.day_of_week}: opening and closing times are required`,
        })
      }
    }
  })
export type HoursInput = z.infer<typeof hoursSchema>

export const langSchema = z.enum(['uz', 'ru', 'en'])
