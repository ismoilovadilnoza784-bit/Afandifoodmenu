import { cookies } from 'next/headers'
import { uz, ru, en, type Dictionary } from './dictionaries'

export const LANGS = ['uz', 'ru', 'en'] as const
export type Lang = (typeof LANGS)[number]

export const dictionaries: Record<Lang, Dictionary> = { uz, ru, en }

export const LOCALE: Record<Lang, string> = { uz: 'uz-UZ', ru: 'ru-RU', en: 'en-US' }

export function isLang(value: unknown): value is Lang {
  return typeof value === 'string' && (LANGS as readonly string[]).includes(value)
}

export function getLang(): Lang {
  const value = cookies().get('lang')?.value
  return isLang(value) ? value : 'uz'
}

export function dict(lang: Lang): Dictionary {
  return dictionaries[lang]
}

/**
 * Localized-field fallback: requested language -> Uzbek -> Russian -> English.
 * Returns '' when the owner has not supplied the content in any language;
 * callers must render an empty state instead of inventing content.
 */
export function pickLocalized(
  row: Record<string, unknown>,
  field: string,
  lang: Lang,
): string {
  const order: Lang[] = [lang, 'uz', 'ru', 'en']
  for (const l of order) {
    const value = row[`${field}_${l}`]
    if (typeof value === 'string' && value.trim() !== '') return value
  }
  return ''
}
