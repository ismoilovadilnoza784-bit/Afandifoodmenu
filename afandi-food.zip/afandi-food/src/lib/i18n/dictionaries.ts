export interface Dictionary {
  menuTitle: string
  menuSubtitle: string
  searchPlaceholder: string
  allCategories: string
  emptyTitle: string
  emptyText: string
  noResults: string
  unavailable: string
  currency: string
  footerContact: string
  footerHours: string
  closedToday: string
  openNow: string
  a11yLanguage: string
  a11yClose: string
  loginTitle: string
  loginSubtitle: string
  loginEmail: string
  loginPassword: string
  loginSubmit: string
  loginError: string
  loginForgot: string
  loginResetSent: string
  backToMenu: string
}

const shape = {
  menuSubtitle: '',
  searchPlaceholder: '',
  allCategories: '',
  emptyTitle: '',
  emptyText: '',
  noResults: '',
  unavailable: '',
  currency: '',
  footerContact: '',
  footerHours: '',
  closedToday: '',
  openNow: '',
  a11yLanguage: '',
  a11yClose: '',
  loginTitle: '',
  loginSubtitle: '',
  loginEmail: '',
  loginPassword: '',
  loginSubmit: '',
  loginError: '',
  loginForgot: '',
  loginResetSent: '',
  backToMenu: '',
} as const

export const uz: Dictionary = {
  ...shape,
  menuTitle: 'Menyu',
  menuSubtitle: 'Afandi Food Samarkand',
  searchPlaceholder: 'Taom qidirish…',
  allCategories: 'Barchasi',
  emptyTitle: 'Menyu hozircha tayyorlanmoqda',
  emptyText: 'Restoran tez orada menyuni yangilaydi. Iltimos, keyinroq qaytib koring.',
  noResults: 'Hech narsa topilmadi',
  unavailable: 'Mavjud emas',
  currency: "so'm",
  footerContact: 'Aloqa',
  footerHours: 'Ish vaqti',
  closedToday: 'Yopiq',
  openNow: 'Ochiq',
  a11yLanguage: 'Tilni tanlash',
  a11yClose: 'Yopish',
  loginTitle: 'Afandi Food boshqaruvi',
  loginSubtitle: 'Faqat egasi uchun',
  loginEmail: 'Email',
  loginPassword: 'Parol',
  loginSubmit: 'Kirish',
  loginError: 'Email yoki parol noto‘g‘ri',
  loginForgot: 'Parolni tiklash',
  loginResetSent: 'Agar akkaunt mavjud bo‘lsa, tikish havolasi emailga yuborildi.',
  backToMenu: 'Menyuga qaytish',
}

export const ru: Dictionary = {
  ...shape,
  menuTitle: 'Меню',
  menuSubtitle: 'Afandi Food Самарканд',
  searchPlaceholder: 'Поиск блюда…',
  allCategories: 'Все',
  emptyTitle: 'Меню скоро появится',
  emptyText: 'Рестран обновит меню в ближайшее время. Пожалуйста, зайдите позже.',
  noResults: 'Ничего не найдено',
  unavailable: 'Нет в наличии',
  currency: 'сум',
  footerContact: 'Контакты',
  footerHours: 'Часы работы',
  closedToday: 'Закрыто',
  openNow: 'Открыто',
  a11yLanguage: 'Выбор языка',
  a11yClose: 'Закрыть',
  loginTitle: 'Управление Afandi Food',
  loginSubtitle: 'Только для владельца',
  loginEmail: 'Email',
  loginPassword: 'Пароль',
  loginSubmit: 'Войти',
  loginError: 'Неверный email или пароль',
  loginForgot: 'Восстановить пароль',
  loginResetSent: 'Если аккаунт существует, ссылка для восстановления отправлена на email.',
  backToMenu: 'Вернуться к меню',
}

export const en: Dictionary = {
  ...shape,
  menuTitle: 'Menu',
  menuSubtitle: 'Afandi Food Samarkand',
  searchPlaceholder: 'Search dishes…',
  allCategories: 'All',
  emptyTitle: 'The menu is on its way',
  emptyText: 'The restaurant will update the menu soon. Please check back later.',
  noResults: 'Nothing found',
  unavailable: 'Unavailable',
  currency: 'UZS',
  footerContact: 'Contact',
  footerHours: 'Opening hours',
  closedToday: 'Closed',
  openNow: 'Open',
  a11yLanguage: 'Choose language',
  a11yClose: 'Close',
  loginTitle: 'Afandi Food management',
  loginSubtitle: 'Owner only',
  loginEmail: 'Email',
  loginPassword: 'Password',
  loginSubmit: 'Sign in',
  loginError: 'Incorrect email or password',
  loginForgot: 'Reset password',
  loginResetSent: 'If the account exists, a reset link has been sent to the email.',
  backToMenu: 'Back to menu',
}
