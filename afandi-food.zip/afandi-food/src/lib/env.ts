function required(name: string): string {
  const value = process.env[name]
  if (!value) {
    throw new Error(
      `[afandi-food] Missing environment variable ${name}.\n` +
        `Copy .env.example to .env.local and fill in the values from ` +
        `Supabase -> Project Settings -> API. See README.md for details.`,
    )
  }
  return value
}

export const env = {
  supabaseUrl: required('NEXT_PUBLIC_SUPABASE_URL'),
  supabaseAnonKey: required('NEXT_PUBLIC_SUPABASE_ANON_KEY'),
}

export const STORAGE_BUCKET = 'menu-images'
