import { createClient } from '@/lib/supabase/server'

/**
 * Returns the authenticated user ONLY if they hold the server-verified
 * 'owner' role in the user_roles table. The browser can never influence
 * this: the check runs with the user's JWT against RLS-protected data,
 * and every mutation is additionally guarded by RLS policies.
 */
export async function requireOwner() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return null

  const { data: role } = await supabase
    .from('user_roles')
    .select('role')
    .eq('user_id', user.id)
    .eq('role', 'owner')
    .maybeSingle()

  return role ? user : null
}
