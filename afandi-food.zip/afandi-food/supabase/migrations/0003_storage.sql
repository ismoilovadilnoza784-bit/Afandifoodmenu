-- 0003_storage.sql — Supabase Storage bucket + policies for menu images.

insert into storage.buckets (id, name, public)
values ('menu-images', 'menu-images', true)
on conflict (id) do nothing;

-- Anyone may VIEW published restaurant images (public bucket + read policy).
create policy "menu_images_public_read" on storage.objects
  for select to anon, authenticated
  using (bucket_id = 'menu-images');

-- Only the verified owner may upload, replace or delete.
-- File type/size are additionally validated in server actions;
-- the client-side check is never trusted.
create policy "menu_images_owner_insert" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'menu-images' and public.is_owner());

create policy "menu_images_owner_update" on storage.objects
  for update to authenticated
  using (bucket_id = 'menu-images' and public.is_owner())
  with check (bucket_id = 'menu-images' and public.is_owner());

create policy "menu_images_owner_delete" on storage.objects
  for delete to authenticated
  using (bucket_id = 'menu-images' and public.is_owner());
