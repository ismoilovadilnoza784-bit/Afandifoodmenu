-- 0002_rls.sql — Row Level Security, owner checks, triggers

alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.categories enable row level security;
alter table public.menu_items enable row level security;
alter table public.restaurant_settings enable row level security;
alter table public.opening_hours enable row level security;

-- SECURITY DEFINER: reads user_roles while bypassing its own RLS,
-- so policy evaluation cannot be tricked by client-supplied claims.
create or replace function public.is_owner()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = auth.uid() and role = 'owner'
  );
$$;

grant execute on function public.is_owner() to anon, authenticated;

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger categories_touch before update on public.categories
  for each row execute function public.touch_updated_at();
create trigger menu_items_touch before update on public.menu_items
  for each row execute function public.touch_updated_at();
create trigger settings_touch before update on public.restaurant_settings
  for each row execute function public.touch_updated_at();

-- Auto-create a profile row for every new auth user.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, new.raw_user_meta_data ->> 'display_name')
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- profiles: users manage only their own row; nothing is publicly exposed.
create policy "profiles_select_own" on public.profiles
  for select to authenticated using (auth.uid() = id);
create policy "profiles_insert_own" on public.profiles
  for insert to authenticated with check (auth.uid() = id);
create policy "profiles_update_own" on public.profiles
  for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- user_roles: a user may read ONLY their own role. Writes happen via
-- the documented privileged setup (SQL in the dashboard), never via API.
create policy "user_roles_select_own" on public.user_roles
  for select to authenticated using (auth.uid() = user_id);

-- categories: public reads published; owner does everything.
create policy "categories_public_read" on public.categories
  for select to anon, authenticated using (is_published = true);
create policy "categories_owner_all" on public.categories
  for all to authenticated using (public.is_owner()) with check (public.is_owner());

-- menu_items: public reads published; owner does everything.
create policy "menu_items_public_read" on public.menu_items
  for select to anon, authenticated using (is_published = true);
create policy "menu_items_owner_all" on public.menu_items
  for all to authenticated using (public.is_owner()) with check (public.is_owner());

-- settings / opening hours: public read; owner write.
create policy "settings_public_read" on public.restaurant_settings
  for select to anon, authenticated using (true);
create policy "settings_owner_write" on public.restaurant_settings
  for all to authenticated using (public.is_owner()) with check (public.is_owner());

create policy "hours_public_read" on public.opening_hours
  for select to anon, authenticated using (true);
create policy "hours_owner_write" on public.opening_hours
  for all to authenticated using (public.is_owner()) with check (public.is_owner());
