-- 0001_schema.sql — Afandi Food: core schema
-- Apply via: Supabase Dashboard -> SQL Editor, or `supabase db push`.

create extension if not exists "uuid-ossp";

-- Protected user profile (created automatically by trigger in 0002)
create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now()
);

-- Server-verified authorization. Rows can only be written by the owner
-- (enforced by RLS in 0002); the browser can never grant itself a role.
create table public.user_roles (
  user_id uuid primary key references auth.users (id) on delete cascade,
  role text not null default 'owner' check (role = 'owner'),
  created_at timestamptz not null default now()
);

create table public.categories (
  id uuid primary key default uuid_generate_v4(),
  name_uz text not null check (char_length(name_uz) <= 120),
  name_ru text check (name_ru is null or char_length(name_ru) <= 120),
  name_en text check (name_en is null or char_length(name_en) <= 120),
  slug text not null unique check (slug ~ '^[a-z0-9-]+$'),
  sort_order integer not null default 0,
  is_published boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.menu_items (
  id uuid primary key default uuid_generate_v4(),
  category_id uuid references public.categories (id) on delete set null,
  name_uz text not null check (char_length(name_uz) <= 160),
  name_ru text check (name_ru is null or char_length(name_ru) <= 160),
  name_en text check (name_en is null or char_length(name_en) <= 160),
  description_uz text check (description_uz is null or char_length(description_uz) <= 2000),
  description_ru text check (description_ru is null or char_length(description_ru) <= 2000),
  description_en text check (description_en is null or char_length(description_en) <= 2000),
  price numeric(12, 2) check (price is null or price >= 0),
  currency text not null default 'UZS' check (currency in ('UZS', 'USD', 'EUR', 'RUB')),
  image_path text,
  is_published boolean not null default false,
  is_available boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index menu_items_category_idx on public.menu_items (category_id, sort_order);
create index menu_items_public_idx on public.menu_items (is_published, sort_order);

create table public.restaurant_settings (
  key text primary key check (key ~ '^[a-z0-9_.-]+$'),
  value jsonb not null,
  updated_at timestamptz not null default now()
);

create table public.opening_hours (
  id uuid primary key default uuid_generate_v4(),
  day_of_week smallint not null unique check (day_of_week between 0 and 6), -- 0 = Monday
  open_time time,
  close_time time,
  is_closed boolean not null default false,
  check (is_closed or (open_time is not null and close_time is not null))
);

-- Branded defaults only: the restaurant's name and currency.
-- NO sample dishes, prices or reviews are ever inserted.
insert into public.restaurant_settings (key, value) values
  ('name', '"Afandi Food"'),
  ('currency', '"UZS"')
on conflict (key) do nothing;
