import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        charcoal: { DEFAULT: '#151311', deep: '#0e0d0b', soft: '#1e1b18' },
        ivory: { DEFAULT: '#f4efe4', dim: '#d9d2c0' },
        gold: { DEFAULT: '#c9a45c', bright: '#e3c785', dark: '#a5823f' },
        muted: '#8f887a',
      },
      fontFamily: {
        serif: ['var(--font-serif)', 'Georgia', 'serif'],
        sans: ['var(--font-sans)', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 2px rgba(0,0,0,.35), 0 8px 24px rgba(0,0,0,.35)',
        glow: '0 0 0 1px rgba(201,164,92,.35)',
      },
      maxWidth: { shell: '72rem' },
    },
  },
  plugins: [],
}
export default config
